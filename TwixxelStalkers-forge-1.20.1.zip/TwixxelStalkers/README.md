# Twixxel Stalker Inspiration – Forge 1.20.1

Port del addon de Bedrock (autor original: Sgsans). Requiere **Forge 47.x**, **Java 17** y **GeckoLib 4.4+**.

## Compilar
1. Abre la carpeta en IntelliJ (importa como Gradle) o ejecuta `gradle wrapper --gradle-version 8.1.1` y luego `./gradlew build`.
2. El .jar queda en `build/libs/`. Ponlo en `mods/` junto con GeckoLib.

## Uso
- Aparecen solos con las mismas reglas del addon (ver `StalkerSpawner.java`).
- Comandos (op): `/stalkers spawn <mob>`, `/stalkers list`, `/stalkers clear`. También hay huevos de aparición en creativo.
- Config en `twixxel_stalkers-common.toml`: multiplicador de spawn, afectar a creativo, etc.

## Ajustes
Velocidades de persecución: constantes en `ChaserMobs.java` (`chase(p, velocidad, salto)`).
Los assets se regeneran con `tools/convert_assets.py` (necesita el addon extraído y ffmpeg).
