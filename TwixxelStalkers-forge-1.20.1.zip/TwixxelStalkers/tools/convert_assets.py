import json, re, glob, os, shutil, subprocess, sys
SRC='/home/claude/src'; OUT='/home/claude/port/TwixxelStalkers/src/main/resources/assets/twixxel_stalkers'
MOD='twixxel_stalkers'
def load(p):
    t=open(p,encoding='utf-8-sig').read()
    try: return json.loads(t)
    except Exception:
        return json.loads(re.sub(r',(\s*[}\]])',r'\1',re.sub(r'(?m)^\s*//.*$','',t)))
for d in ['geo','animations','textures/entity','sounds','lang','models/item','font','textures/gui']:
    os.makedirs(f'{OUT}/{d}',exist_ok=True)

# entity ids from client defs
ids=sorted(os.path.basename(f)[:-5] for f in glob.glob(f'{SRC}/RP/entity/*.json'))
# animations
allanims={}
for f in glob.glob(f'{SRC}/RP/animations/*.json'):
    for k,v in load(f).get('animations',{}).items(): allanims[k]=v
report={}
for eid in ids:
    cd=load(f'{SRC}/RP/entity/{eid}.json')['minecraft:client_entity']['description']
    # geo
    shutil.copy(f'{SRC}/RP/models/entity/{eid}.geo.json', f'{OUT}/geo/{eid}.geo.json')
    # texture
    tex=cd['textures']['default'].split('/')[-1]
    shutil.copy(f'{SRC}/RP/textures/entity/{tex}.png', f'{OUT}/textures/entity/{eid}.png')
    # anims
    merged={}
    for short,full in cd.get('animations',{}).items():
        if full.startswith('controller.'): continue
        if full in allanims: merged[full]=allanims[full]
    # also grab any animation prefixed with animation.<eid>.
    for k,v in allanims.items():
        if (k.startswith(f'animation.{eid}.') or k==f'animation.{eid}') and k not in merged: merged[k]=v
    json.dump({'format_version':'1.8.0','animations':merged}, open(f'{OUT}/animations/{eid}.animation.json','w'), separators=(',',':'))
    report[eid]=sorted(merged.keys())
json.dump(report,open('/home/claude/anim_report.json','w'),indent=1)

# UI death image for jumpscare font
shutil.copy(f'{SRC}/RP/textures/ui/death.png', f'{OUT}/textures/gui/death.png')
json.dump({"providers":[{"type":"bitmap","file":f"{MOD}:textures/gui/death.png","ascent":24,"height":48,"chars":["\ue100"]}]},open(f'{OUT}/font/jumpscare.json','w'))

# sounds
defs=load(f'{SRC}/RP/sounds/sound_definitions.json')['sound_definitions']
files={}
for root,_,fs in os.walk(f'{SRC}/RP/sounds'):
    for fn in fs:
        if fn.endswith(('.ogg','.mp3')):
            rel=os.path.relpath(os.path.join(root,fn),f'{SRC}/RP/sounds'); files[os.path.splitext(rel)[0]]=os.path.join(root,fn)
used=set(); sounds={}; skipped=[]
def convert(rel):
    src=files[rel]; dst=f'{OUT}/sounds/{rel}.ogg'; os.makedirs(os.path.dirname(dst),exist_ok=True)
    if src.endswith('.ogg'): shutil.copy(src,dst)
    else: subprocess.run(['ffmpeg','-y','-loglevel','error','-i',src,'-c:a','libvorbis',dst],check=True)
for name,v in defs.items():
    ent=[]
    for s in v['sounds']:
        path=(s['name'] if isinstance(s,dict) else s).replace('sounds/','',1)
        if path not in files:
            base=os.path.basename(path); cand=[k for k in files if os.path.basename(k)==base or os.path.basename(k).replace('_','')==base.replace('_','')[::-1][::-1] and False]
            cand=[k for k in files if os.path.basename(k)==base] or [k for k in files if os.path.basename(k).split('_')[::-1]==base.split('_')]
            if cand: path=cand[0]
            else: skipped.append((name,path)); continue
        convert(path); used.add(path); ent.append(path)
    if ent: sounds[name]=ent
# extra sounds that exist as files but are not defined (referenced by native entity events etc.)
for rel in files:
    if rel not in used:
        n=os.path.basename(rel)
        if n not in sounds and rel.split('/')[0] in ('stalker_chase','stalker_ambient','entity_x','cave_stalker_up','anguish','tormentor','c_stalker_bed','cave_stalker_chase','cave_stalker','tree_stalker','tortured','something','stalker','tormentor_door','stalker_door_2','c_stalker','stalker_bed'):
            convert(rel); sounds[n]=[rel]; used.add(rel)
sj={}
for n,ps in sounds.items():
    sj[n]={"sounds":[{"name":f"{MOD}:{p}","stream":False} for p in ps]}
json.dump(sj,open(f'{OUT}/sounds.json','w'),indent=1)
json.dump(sorted(sounds.keys()),open('/home/claude/sound_names.json','w'))
print("sounds:",sorted(sounds)); print("skipped defs:",skipped)
print("unused files:",[k for k in files if k not in used])
print(len(ids),"entities",ids)
