package com.twixxel.stalkers.entity;

import com.twixxel.stalkers.StalkerScheduler;
import com.twixxel.stalkers.util.StalkerUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;

/** Mobs que persiguen / matan: hunt, something, stalker3, silent, yelling_creature, ice_stalker, raro, c_stalker, tortured, evil_hunt. */
public final class ChaserMobs {
    private ChaserMobs() {}

    public static class Hunt extends StalkerEntity {
        private int walkTimer;
        public Hunt(EntityType<? extends StalkerEntity> t, Level l) { super(t, l); maxLife = 80; }
        @Override protected void serverBehavior() {
            ServerPlayer p = nearest(128);
            if (p == null) return;
            face(p);
            if (life >= 50) { discard(); return; }
            if (distanceTo(p) <= 1.2F) { StalkerUtil.kill(p); discard(); return; }
            if (++walkTimer >= 20) {
                walkTimer = 0;
                StalkerUtil.playAt(level(), position(), "walk" + (1 + random.nextInt(3)), 0.7F);
            }
            chase(p, 0.30, 0.42);
        }
        @Override protected String animationFor(int s, boolean moving) { return moving ? "animation.hunt.h_walk" : null; }
    }

    /** Se congela mientras lo miras (0 = corre, 1 = congelado). */
    public static class Something extends StalkerEntity {
        private int soundTicks;
        public Something(EntityType<? extends StalkerEntity> t, Level l) { super(t, l); maxLife = 9000; }
        @Override protected void serverBehavior() {
            ServerPlayer p = nearest(200);
            if (p == null) return;
            if (distanceTo(p) <= 1.2F) { StalkerUtil.kill(p); discard(); return; }
            face(p);
            if (StalkerUtil.looking(p, this, 0.4)) {
                if (getState() != 1) { setState(1); }
                setDeltaMovement(0, getDeltaMovement().y, 0);
                if (++soundTicks >= 300) {
                    soundTicks = 0;
                    StalkerUtil.playLocal(p, random.nextBoolean() ? "l2" : "l3", 1.5F);
                }
                return;
            }
            if (getState() == 1) setState(0);
            soundTicks = 0;
            chase(p, 0.36, 0.4);
        }
        @Override protected String animationFor(int s, boolean m) { return s == 0 ? "animation.something.so_run" : null; }
    }

    /** 0 idle, 1 aviso, 2 persecucion. */
    public static class Stalker3 extends StalkerEntity {
        private boolean audio;
        public Stalker3(EntityType<? extends StalkerEntity> t, Level l) { super(t, l); maxLife = 4000; }
        @Override protected void serverBehavior() {
            ServerPlayer p = nearest(128);
            if (p == null) return;
            face(p);
            switch (getState()) {
                case 0 -> { if (distanceTo(p) <= 8) setState(1); else if (stateTicks >= 2000) discard(); }
                case 1 -> {
                    if (!audio) { audio = true; StalkerUtil.playLocal(p, "s3_chase", 2.0F); }
                    if (stateTicks >= 30) setState(2);
                }
                default -> {
                    if (distanceTo(p) <= 1.5F) { StalkerUtil.stopLocal(p, "s3_chase"); StalkerUtil.kill(p); discard(); return; }
                    chase(p, 0.36, 0.55);
                    if (stateTicks >= 1400) { StalkerUtil.stopLocal(p, "s3_chase"); discard(); }
                }
            }
        }
        @Override protected String animationFor(int s, boolean m) {
            return s == 1 ? "animation.stalker3.s3_notice_player" : s == 2 ? "animation.stalker3.s3_run" : null;
        }
    }

    /** 0 idle, 1 acecho (zigzag), 2 aviso, 3 corre. */
    public static class Silent extends StalkerEntity {
        private boolean grace;
        public Silent(EntityType<? extends StalkerEntity> t, Level l) { super(t, l); maxLife = 4000; }
        @Override protected void serverBehavior() {
            ServerPlayer p = nearest(128);
            if (p == null) return;
            face(p);
            float d = distanceTo(p);
            switch (getState()) {
                case 0 -> {
                    if (d <= 5) { setState(1); if (!grace) { grace = true; StalkerUtil.playLocal(p, "grace", 2.0F); } }
                    else if (stateTicks >= 1200) discard();
                }
                case 1 -> {
                    Vec3 dir = p.position().subtract(position());
                    double len = Math.hypot(dir.x, dir.z);
                    if (len > 0) {
                        double zz = Math.sin(tickCount * 0.2) * 0.075;
                        move(net.minecraft.world.entity.MoverType.SELF,
                                new Vec3(dir.x / len * 0.05 + zz, 0, dir.z / len * 0.05 + zz));
                    }
                    if (stateTicks >= 200) { setState(2); StalkerUtil.playLocal(p, "grace3", 2.0F); }
                }
                case 2 -> { if (stateTicks >= 60) setState(3); }
                default -> {
                    if (random.nextFloat() < 0.05F) StalkerUtil.playAt(level(), position(), "walk" + (1 + random.nextInt(3)), 1.0F);
                    if (d <= 1.5F) { StalkerUtil.kill(p); discard(); return; }
                    chase(p, 0.36, 0.55);
                    if (stateTicks >= 600) discard();
                }
            }
        }
        @Override protected String animationFor(int s, boolean m) {
            return switch (s) { case 1 -> "animation.silent.slt_stalk"; case 2 -> "animation.silent.slt_notice_player";
                case 3 -> "animation.silent.slt_run"; default -> null; };
        }
    }

    /** 0 idle, 1 aviso, 2 corre. */
    public static class YellingCreature extends StalkerEntity {
        private boolean audio;
        public YellingCreature(EntityType<? extends StalkerEntity> t, Level l) { super(t, l); maxLife = 2000; }
        @Override protected void serverBehavior() {
            ServerPlayer p = nearest(128);
            if (p == null) return;
            face(p);
            switch (getState()) {
                case 0 -> { if (distanceTo(p) <= 6) setState(1); }
                case 1 -> {
                    if (!audio) { audio = true; StalkerUtil.playLocal(p, "yelling_chase", 2.0F); }
                    if (stateTicks >= 16) setState(2);
                }
                default -> {
                    if (distanceTo(p) <= 1.2F) { StalkerUtil.stopForAll(sl(), "yelling_chase"); StalkerUtil.kill(p); discard(); return; }
                    StalkerUtil.openDoors(level(), blockPosition(), 1, 1, 1);
                    chase(p, 0.40, 0.55);
                }
            }
        }
        @Override protected String animationFor(int s, boolean m) {
            return s == 0 ? "animation.yelling_creature.y_idle" : s == 1 ? "animation.yelling_creature.y_notice_player" : "animation.yelling_creature.y_run";
        }
    }

    /** 0 idle, 1 sube (rompe el hielo), 2 corre. */
    public static class IceStalker extends StalkerEntity {
        private int warn, grace;
        private boolean warned, audio;
        private Vec3 lock;
        public IceStalker(EntityType<? extends StalkerEntity> t, Level l) { super(t, l); maxLife = 6000; }
        @Override protected void serverBehavior() {
            ServerPlayer p = nearest(128);
            if (p == null) return;
            float d = distanceTo(p);
            int st = getState();
            if (st != 1) face(p);
            if (st == 0) {
                if (d <= 2.0F) {
                    Vec3 v = p.getViewVector(1F);
                    Vec3 to = position().subtract(p.position());
                    double len = Math.hypot(to.x, to.z);
                    double dot = len == 0 ? 0 : (v.x * to.x + v.z * to.z) / len;
                    if (dot > 0.5 && !warned && ++warn >= 60) {
                        StalkerUtil.actionbar(p, "§cAléjate");
                        StalkerUtil.playAt(level(), position(), "stalker_2", 2.0F);
                        warned = true; grace = 0;
                    }
                }
                if (warned) {
                    grace++;
                    if (d > 5.0F) { warned = false; warn = 0; grace = 0; }
                    else if (grace >= 140) {
                        setState(1);
                        lock = position();
                        BlockPos c = blockPosition();
                        for (int x = -2; x <= 2; x++) for (int y = -2; y <= 2; y++) for (int z = -2; z <= 2; z++) {
                            BlockPos b = c.offset(x, y, z);
                            if (StalkerUtil.isIce(level().getBlockState(b))) level().setBlock(b, Blocks.AIR.defaultBlockState(), 3);
                        }
                    }
                }
            } else if (st == 1) {
                if (!audio) { audio = true; StalkerUtil.playLocal(p, "ch_ice_s", 2.0F); }
                if (lock != null) { setPos(lock); setDeltaMovement(Vec3.ZERO); }
                if (stateTicks >= 180) setState(2);
            } else {
                if (!audio) { audio = true; StalkerUtil.playLocal(p, "ch_ice_s", 2.0F); }
                if (d <= 1.2F) { StalkerUtil.stopLocal(p, "ch_ice_s"); StalkerUtil.kill(p); discard(); return; }
                chase(p, 0.38, 0.55);
            }
        }
        @Override protected String animationFor(int s, boolean m) {
            return s == 0 ? "animation.ice_stalker.is_idle" : s == 1 ? "animation.ice_stalker.is_up" : "animation.ice_stalker.is_run";
        }
    }

    /** 0 idle, 1 dialogo, 2 persecucion, 3 atrapado. */
    public static class Raro extends StalkerEntity {
        private static final int[] AT = {20, 80, 160, 260};
        private static final String[] MSG = {"cómo te llamas?", "¿te gustan los dulces?", "acércate te daré algunos", "¿por qué no te acercas?"};
        private int lookTicks, dTimer, step, chaseTimer, trapTimer;
        public Raro(EntityType<? extends StalkerEntity> t, Level l) { super(t, l); maxLife = 3000; }

        private void say(String s) { sl().getServer().getPlayerList().broadcastSystemMessage(Component.literal(s), false); }
        private void trap(ServerPlayer p) {
            setState(3); trapTimer = 0;
            StalkerUtil.playAt(level(), position(), "trap", 3.0F);
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 120, 10, false, true));
        }
        @Override protected void serverBehavior() {
            ServerPlayer p = nearest(128);
            if (p == null) return;
            if (getState() != 3) face(p);
            float d = distanceTo(p);
            switch (getState()) {
                case 0 -> {
                    if (d <= 12 && StalkerUtil.looking(p, this, 0.80)) {
                        if (++lookTicks >= 100) {
                            setState(1); step = 0; dTimer = 0;
                            say("hola pequeño");
                            StalkerUtil.playAt(level(), position(), "mom", 3.0F);
                        }
                    } else if (lookTicks > 0) lookTicks--;
                }
                case 1 -> {
                    dTimer++;
                    if (d <= 3.5F) { trap(p); return; }
                    if (step < 4 && dTimer >= AT[step]) { say(MSG[step]); step++; if (step == 4) dTimer = 0; }
                    else if (step == 4 && dTimer >= 140) { setState(2); chaseTimer = 0; }
                }
                case 2 -> {
                    chaseTimer++;
                    StalkerUtil.actionbar(p, "§c!! ACERCATEE!!");
                    chase(p, 0.30, getDeltaMovement().y);
                    if (d <= 3.5F) { trap(p); return; }
                    if (chaseTimer >= 800) discard();
                }
                default -> {
                    StalkerUtil.actionbar(p, "§cbien hecho");
                    if (++trapTimer >= 100) { StalkerUtil.kill(p); discard(); }
                }
            }
        }
        @Override protected String animationFor(int s, boolean m) { return s == 2 ? "animation.raro.r_run" : "animation.raro.r_idle"; }
    }

    /** 0 idle, 1 aviso, 2 corre, 3 puerta, ademas chasingDoor. */
    public static class CStalker extends StalkerEntity {
        private boolean soundPlayed, doorSound, chaseDoor;
        private int doorTimer = -1;
        public CStalker(EntityType<? extends StalkerEntity> t, Level l) { super(t, l); maxLife = 6000; }
        public void setDoorState() { setState(3); }

        @Override protected void serverBehavior() {
            ServerPlayer p = nearest(128);
            if (p == null) return;
            face(p);
            float d = distanceTo(p);
            switch (getState()) {
                case 0 -> {
                    if (StalkerUtil.looking(p, this, 0.4)) {
                        setState(1);
                        if (!soundPlayed) { soundPlayed = true; StalkerUtil.playLocal(p, "look_c_stalker", 1.5F); }
                    }
                }
                case 1 -> { if (stateTicks >= 30) setState(2); }
                case 2 -> {
                    if (d <= 1.2F) { StalkerUtil.stopLocal(p, "look_c_stalker"); StalkerUtil.kill(p); discard(); return; }
                    chase(p, 0.30, 0.38);
                    if (!chaseDoor && StalkerUtil.nearDoor(level(), p.position(), 1)) {
                        StalkerUtil.stopLocal(p, "look_c_stalker");
                        final Vec3 pos = p.position();
                        final net.minecraft.server.level.ServerLevel lvl = sl();
                        discard();
                        if (random.nextBoolean()) StalkerScheduler.runLater(120, () -> ambush(lvl, p, pos));
                    }
                }
                default -> { // puerta
                    if (chaseDoor) {
                        if (d <= 1.2F) { StalkerUtil.stopLocal(p, "look_c_stalker"); StalkerUtil.kill(p); discard(); return; }
                        chase(p, 0.30, 0.38);
                        if (--doorTimer == 0 && random.nextBoolean()) { StalkerUtil.stopLocal(p, "look_c_stalker"); discard(); }
                        return;
                    }
                    if (!doorSound && StalkerUtil.looking(p, this, 0.4)) { doorSound = true; doorTimer = 0; StalkerUtil.playAt(level(), position(), "cs_door", 4.5F); }
                    if (doorSound) {
                        doorTimer++;
                        if (doorTimer == 140) StalkerUtil.actionbar(p, "§cNo me veas");
                        if (doorTimer == 240) { chaseDoor = true; doorTimer = 100; setStateRun(); }
                    }
                }
            }
        }
        private void setStateRun() { this.entityData.set(DATA_STATE, 2); stateTicks = 0; }

        static void ambush(net.minecraft.server.level.ServerLevel lvl, ServerPlayer p, Vec3 pos) {
            if (!p.isAlive() || p.level() != lvl) return;
            StalkerUtil.openDoors(lvl, BlockPos.containing(pos), 2, 1, 2);
            StalkerEntity e = com.twixxel.stalkers.StalkerSpawner.spawn(lvl, "c_stalker", pos);
            if (e instanceof CStalker c) c.setDoorState();
        }
        @Override protected String animationFor(int s, boolean m) {
            return switch (s) { case 1 -> "animation.c_stalker.cs_notice_player"; case 2 -> "animation.c_stalker.cs_run";
                case 3 -> "animation.c_stalker.cs_door"; default -> "animation.c_stalker.cs_idle"; };
        }
    }

    /** 0 idle (mira al cristal), 1 aviso, 2 rompe ventana, 3 corre. */
    public static class Tortured extends StalkerEntity {
        private Vec3 glass;
        private boolean triggered, audio;
        private int trigTicks;
        public Tortured(EntityType<? extends StalkerEntity> t, Level l) { super(t, l); makeStatic(); maxLife = 9000; }
        public void setGlass(Vec3 g) { this.glass = g; }

        @Override protected void serverBehavior() {
            if (!triggered) {
                if (glass == null) {
                    BlockPos g = StalkerUtil.nearestBlock(level(), position(), 3, 2, 3, StalkerUtil::isGlass);
                    if (g != null) glass = Vec3.atCenterOf(g);
                }
                if (glass != null) StalkerUtil.face(this, glass);
                for (ServerPlayer p : StalkerUtil.playersNear(level(), position(), 15)) {
                    if (StalkerUtil.looking(p, this, 0.60)) { triggered = true; trigTicks = 0; setState(1); break; }
                }
                return;
            }
            if (getState() < 3) {
                trigTicks++;
                if (trigTicks == 40) { setState(2); StalkerUtil.playAt(level(), position(), "td_bw", 3.0F); }
                if (trigTicks >= 220) {
                    StalkerUtil.breakGlass(level(), blockPosition(), 2, -1, 3, 2);
                    makeSolid();
                    setState(3);
                }
                return;
            }
            if (!audio) {
                audio = true;
                for (ServerPlayer q : StalkerUtil.playersNear(level(), position(), 20)) StalkerUtil.playLocal(q, "running_td", 1.5F);
            }
            ServerPlayer p = nearest(128);
            if (p == null) return;
            if (distanceTo(p) <= 1.2F) {
                StalkerUtil.stopForAll(sl(), "running_td");
                StalkerUtil.kill(p); discard(); return;
            }
            chase(p, 0.40, 0.45);
        }
        @Override protected String animationFor(int s, boolean m) {
            return switch (s) { case 1 -> "animation.tortured.td_notice_player"; case 2 -> "animation.tortured.td_broke_window";
                case 3 -> "animation.tortured.td_run"; default -> "animation.tortured.td_idle"; };
        }
    }

    /** Aparece a ~70 bloques, se acerca en linea recta; 1 = corriendo. */
    public static class EvilHunt extends StalkerEntity {
        private boolean p30, p0, ranTitle;
        public EvilHunt(EntityType<? extends StalkerEntity> t, Level l) { super(t, l); makeStatic(); maxLife = 1400; }
        @Override protected void serverBehavior() {
            ServerPlayer p = nearest(400);
            if (p == null) return;
            double d = distanceTo(p);
            if (d > 25 && !p30) { p30 = true; StalkerUtil.playLocal(p, "30s", 2.0F); }
            stepToward(p, 0.27, false);
            if (d <= 10 && getState() == 0) setState(1);
            if (d > 25) {
                if (tickCount % 5 == 0) StalkerUtil.actionbar(p, "it is " + (int) d + " blocks away from you");
            } else if (d > 1.8) {
                if (!p0) { p0 = true; StalkerUtil.playLocal(p, "0s", 2.0F); }
                if (!ranTitle) { ranTitle = true; StalkerUtil.title(p, "§4§lRUN"); }
                if (tickCount % 5 == 0) StalkerUtil.actionbar(p, "§c⚠️!RUN! " + (int) d + " blocks | " + Math.max(0, 60 - life / 20) + "s");
            } else {
                StalkerUtil.playLocal(p, "custom_player_death", 2.0F);
                StalkerUtil.kill(p);
                StalkerUtil.stopAll(sl());
                discard(); return;
            }
            if (life > 1200) { StalkerUtil.actionbar(p, "§aSobreviviste a la cacería... por ahora."); discard(); }
        }
        @Override protected String animationFor(int s, boolean m) { return s == 1 ? "animation.evil_hunt.ev_run" : null; }
    }
}
