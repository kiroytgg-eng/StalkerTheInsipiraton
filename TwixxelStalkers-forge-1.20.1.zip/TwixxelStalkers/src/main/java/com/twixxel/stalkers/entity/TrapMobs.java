package com.twixxel.stalkers.entity;

import com.twixxel.stalkers.StalkerSpawner;
import com.twixxel.stalkers.util.StalkerUtil;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Mobs de trampa: tree_stalker, c_stalker_bed, stalker_bed, stalker_up, cave_stalker. */
public final class TrapMobs {
    private TrapMobs() {}

    /** 0 asoma, 1 esconde, 2 trampa. */
    public static class TreeStalker extends StalkerEntity {
        public TreeStalker(EntityType<? extends StalkerEntity> t, Level l) { super(t, l); makeStatic(); maxLife = 6000; }
        @Override protected void serverBehavior() {
            if (getState() == 2) { if (stateTicks >= 80) discard(); return; }
            for (ServerPlayer p : StalkerUtil.playersNear(level(), position(), 4.5)) {
                setState(2);
                StalkerUtil.playAt(level(), position(), "trap", 10.0F);
                StalkerUtil.title(p, "§4¡muerto!");
                p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 80, 1, false, false));
                StalkerUtil.hurt(p, 50);
                return;
            }
        }
        @Override protected String animationFor(int s, boolean m) {
            return s == 0 ? "animation.tree_stalker.peek" : s == 1 ? "animation.tree_stalker.hide" : "animation.tree_stalker.trap";
        }
    }

    /** 0 idle, 1 te noto, 2 esperando a que mires atras. */
    public static class CStalkerBed extends StalkerEntity {
        public CStalkerBed(EntityType<? extends StalkerEntity> t, Level l) { super(t, l); makeStatic(); maxLife = 4000; }
        @Override protected void serverBehavior() {
            ServerPlayer near = nearest(128);
            switch (getState()) {
                case 0 -> {
                    for (ServerPlayer p : StalkerUtil.playersNear(level(), position(), 128)) {
                        if (StalkerUtil.looking(p, this, 0.4)) {
                            setState(1);
                            StalkerUtil.playAt(level(), position(), "bed_look", 5.0F);
                            break;
                        }
                    }
                }
                case 1 -> {
                    if (near != null) face(near);
                    if (stateTicks >= 200 && near != null) {
                        setState(2);
                        double yaw = Math.toRadians(near.getYRot());
                        setPos(near.getX() + Math.sin(yaw) * 2, near.getY(), near.getZ() - Math.cos(yaw) * 2);
                        StalkerUtil.face(this, near.position());
                        StalkerUtil.playAt(level(), position(), "th_scream", 2.0F);
                    }
                }
                default -> {
                    for (ServerPlayer p : StalkerUtil.playersNear(level(), position(), 128)) {
                        if (StalkerUtil.looking(p, this, 0.4)) { StalkerUtil.kill(p); discard(); return; }
                    }
                }
            }
        }
        @Override protected String animationFor(int s, boolean m) {
            return s == 1 ? "animation.c_stalker_bed.cb_notice_player" : "animation.c_stalker_bed.cb_idle";
        }
    }

    /** Aparece delante de un jugador que duerme. state 0 = stalk_bed, 1 = dawn. Mata a los jugadores a <5 bloques a los 9 s. */
    public static class StalkerBed extends StalkerEntity {
        public StalkerBed(EntityType<? extends StalkerEntity> t, Level l) { super(t, l); makeStatic(); maxLife = 400; }
        public void start(ServerPlayer target) {
            StalkerUtil.face(this, target.position());
            setState(random.nextBoolean() ? 0 : 1);
            StalkerUtil.playAt(level(), position(), "stalker", 2.5F);
            StalkerUtil.playAt(level(), position(), "cave_stalker", 1.0F);
        }
        @Override protected void serverBehavior() {
            ServerPlayer p = nearest(32);
            if (p != null) face(p);
            if (life >= 180) { damageNearbyPlayers(5); discard(); }
        }
        @Override protected String animationFor(int s, boolean m) {
            return s == 0 ? "animation.stalker_bed.stalk_bed" : "animation.stalker_bed.stalker_dawn_bed";
        }
    }

    /** Detras del jugador; si miras arriba te hace daño. 0 = idle, 1 = trampa. */
    public static class StalkerUp extends StalkerEntity {
        private int freeze;
        public StalkerUp(EntityType<? extends StalkerEntity> t, Level l) { super(t, l); makeStatic(); maxLife = 450; }
        @Override protected void serverBehavior() {
            ServerPlayer p = nearest(64);
            if (getState() == 1) {
                if (freeze > 0 && p != null) {
                    freeze--;
                    p.connection.teleport(p.getX(), p.getY(), p.getZ(), p.getYRot(), -75F);
                }
                if (stateTicks >= 30) discard();
                return;
            }
            if (life >= 400) { discard(); return; }
            if (p == null) return;
            StalkerUtil.actionbar(p, "§cNo mires arriba");
            double yaw = Math.toRadians(p.getYRot());
            setPos(p.getX() + Math.sin(yaw) * 0.7, p.getY(), p.getZ() - Math.cos(yaw) * 0.7);
            setYRot(p.getYRot()); setXRot(0); yHeadRot = p.getYRot(); yBodyRot = p.getYRot();
            if (p.getXRot() < -40) {
                setState(1);
                freeze = 20;
                StalkerUtil.playAt(level(), position(), "j_su", 1.5F);
                StalkerUtil.hurt(p, 10);
            }
        }
        @Override protected String animationFor(int s, boolean m) {
            return s == 0 ? "animation.stalker_up.su_idle" : "animation.stalker_up.su_trap";
        }
    }

    /** 0 idle, 1 acecha 13 s y se convierte en cave_stalker_chase. */
    public static class CaveStalker extends StalkerEntity {
        public CaveStalker(EntityType<? extends StalkerEntity> t, Level l) { super(t, l); makeStatic(); maxLife = 3000; }
        @Override protected void serverBehavior() {
            ServerPlayer p = nearest(64);
            if (p != null) face(p);
            if (getState() == 0) {
                if (p != null && distanceTo(p) <= 5) {
                    setState(1);
                    StalkerUtil.playAt(level(), position(), "cave_stalker", 1.0F);
                }
            } else if (stateTicks >= 260) {
                double yaw = Math.toRadians(getYRot());
                Vec3 pos = position().add(Math.cos(yaw), 0, Math.sin(yaw));
                StalkerSpawner.spawn(sl(), "cave_stalker_chase", pos);
                discard();
            }
        }
        @Override protected String animationFor(int s, boolean m) {
            return s == 0 ? "animation.cave_stalker_idle" : "animation.cave_stalker_stalk";
        }
    }
}
