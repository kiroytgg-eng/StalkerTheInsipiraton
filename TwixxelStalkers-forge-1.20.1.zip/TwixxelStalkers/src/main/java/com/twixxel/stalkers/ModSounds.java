package com.twixxel.stalkers;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Todos los sonidos del addon original (mismos nombres que sound_definitions.json). */
public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, TwixxelStalkers.MODID);
    private static final Map<String, RegistryObject<SoundEvent>> MAP = new HashMap<>();

    public static final String[] NAMES = {
        "0s",
        "30s",
        "ambice",
        "anguish",
        "bed_look",
        "cave_stalker",
        "cave_whispers",
        "ch_ice_s",
        "chasing_stalker",
        "creepy_wind",
        "cs_door",
        "cup_hide",
        "custom_player_death",
        "d1",
        "dark_ambient",
        "distant_screamer",
        "entity_x_chase",
        "ghostly_moan",
        "grace",
        "grace2",
        "grace3",
        "horror_drone",
        "j_entity_x",
        "j_su",
        "j_tormentor",
        "jumpscare_staller_chase",
        "knock",
        "l2",
        "l3",
        "l4",
        "l5",
        "look_c_stalker",
        "look_s_d",
        "look_sd_3",
        "mom",
        "outside",
        "pf",
        "pulse",
        "running_td",
        "s2",
        "s3",
        "s3_chase",
        "sd3",
        "stalker",
        "stalker1",
        "stalker2",
        "stalker3",
        "stalker4",
        "stalker5",
        "stalker6",
        "stalker7",
        "stalker8",
        "stalker9",
        "stalker_2",
        "td_bw",
        "td_jumpscare",
        "th_scream",
        "tormentor_door",
        "tormentor_r",
        "trap",
        "w_tdr",
        "walk1",
        "walk2",
        "walk3",
        "y_man",
        "yelling_chase"
    };

    static {
        for (String n : NAMES) {
            MAP.put(n, SOUNDS.register(n, () -> SoundEvent.createVariableRangeEvent(
                    new ResourceLocation(TwixxelStalkers.MODID, n))));
        }
    }

    /** @return el sonido o null si no existe (el addon original referenciaba algunos que no traia). */
    public static SoundEvent get(String name) {
        RegistryObject<SoundEvent> r = MAP.get(name);
        return r == null ? null : r.get();
    }

    private ModSounds() {}
}
