package com.twixxel.stalkers.entity;

import com.twixxel.stalkers.util.StalkerUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Mobs ligados a puertas, ventanas y tuneles. */
public final class DoorMobs {
    private DoorMobs() {}

    private static void faceGlass(StalkerEntity e) {
        if (e.tickCount % 10 != 0) return;
        BlockPos g = StalkerUtil.nearestBlock(e.level(), e.position(), 6, 4, 6, StalkerUtil::isGlass);
        if (g != null) StalkerUtil.face(e, Vec3.atCenterOf(g));
    }

    /** 0 idle, 1 puerta (te vio), 2 trampa. */
    public static class StalkerDoor2 extends StalkerEntity {
        private int phase;
        public StalkerDoor2(EntityType<? extends StalkerEntity> t, Level l) { super(t, l); makeStatic(); maxLife = 6000; }
        @Override protected void serverBehavior() {
            ServerPlayer p = nearest(128);
            if (p == null) return;
            face(p);
            if (tickCount % 5 == 0) StalkerUtil.openDoors(level(), blockPosition(), 1, 0, 1);
            if (tickCount % 40 == 0 && distanceTo(p) <= 25)
                p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 200, 1, false, true));
            switch (getState()) {
                case 0 -> {
                    if (StalkerUtil.looking(p, this, 0.80)) {
                        setState(1); phase = 0;
                        StalkerUtil.playAt(level(), position(), "look_sd_3", 5.0F);
                        p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 600, 1, false, true));
                        StalkerUtil.title(p, "§cHuye");
                    }
                }
                case 1 -> {
                    if (++phase >= 200) {
                        if (StalkerUtil.blocked(level(), this, p)) {
                            StalkerUtil.actionbar(p, "§aSobreviviste");
                            discard();
                        } else {
                            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 1, false, true));
                            double yaw = Math.toRadians(p.getYRot());
                            setPos(p.getX() - Math.sin(yaw) * 1.5, p.getY(), p.getZ() + Math.cos(yaw) * 1.5);
                            StalkerUtil.title(p, "§cTe lo advertí");
                            StalkerUtil.playAt(level(), p.position(), "jumpscare_staller_chase", 1.0F);
                            setState(2); phase = 0;
                        }
                    }
                }
                default -> {
                    if (++phase >= 40) {
                        if (distanceTo(p) <= 2.0F) StalkerUtil.kill(p);
                        discard();
                    }
                }
            }
        }
        @Override protected String animationFor(int s, boolean m) {
            return s == 0 ? "animation.stalker_door_2.s_idle" : "animation.stalker_door_2.s_door";
        }
    }

    /** 0 espera mirada, 1 "subiendo" y despues mata. */
    public static class StalkerDoor3 extends StalkerEntity {
        private int stare;
        public StalkerDoor3(EntityType<? extends StalkerEntity> t, Level l) { super(t, l); makeStatic(); maxLife = 6000; }
        @Override protected void serverBehavior() {
            faceGlass(this);
            if (getState() == 0) {
                ServerPlayer p = nearest(999);
                if (p == null) return;
                double d = distanceTo(p);
                if (d <= 15 && StalkerUtil.looking(p, this, 0.85) && ++stare >= 100) {
                    setState(1);
                    StalkerUtil.playAt(level(), position(), "sd3", 3.0F);
                }
            } else if (stateTicks >= 360) {
                damageNearbyPlayers(10);
                discard();
            }
        }
        @Override protected String animationFor(int s, boolean m) {
            return s == 0 ? "animation.stalker_door_3.d3_idle" : "animation.stalker_door_3.uping";
        }
    }

    /** 0 idle, 1 puerta rota y te acecha. */
    public static class SilentDoor extends StalkerEntity {
        public SilentDoor(EntityType<? extends StalkerEntity> t, Level l) { super(t, l); makeStatic(); maxLife = 6000; }
        @Override protected void serverBehavior() {
            faceGlass(this);
            ServerPlayer p = nearest(128);
            if (p == null) return;
            if (getState() == 0) {
                if (StalkerUtil.looking(p, this, 0.4)) {
                    setState(1);
                    BlockPos b = blockPosition();
                    level().destroyBlock(b, false);
                    level().destroyBlock(b.above(), false);
                }
                return;
            }
            StalkerUtil.openDoors(level(), blockPosition(), 2, 2, 2);
            if (distanceTo(p) <= 1.5F) { StalkerUtil.kill(p); discard(); return; }
            if (stateTicks % 80 == 0) StalkerUtil.playAt(level(), position(), random.nextBoolean() ? "s2" : "s3", 1.0F);
            if (stateTicks >= 140) { StalkerUtil.hurt(p, 10); discard(); }
        }
        @Override protected String animationFor(int s, boolean m) {
            return s == 0 ? "animation.silent_door.sl_idle" : "animation.silent_door.sl_door";
        }
    }

    /** 0 puerta (estatico, mata de cerca / se va si lo miras), 1 corre por la ventana. */
    public static class Tormentor extends StalkerEntity {
        private Vec3 dir;
        public Tormentor(EntityType<? extends StalkerEntity> t, Level l) { super(t, l); makeStatic(); maxLife = 3000; }
        public void setWindowRun() { setState(1); makeSolid(); }
        @Override protected void serverBehavior() {
            if (getState() == 1) {
                if (dir == null) {
                    double a = random.nextDouble() * Math.PI * 2;
                    dir = new Vec3(Math.cos(a), 0, Math.sin(a));
                    StalkerUtil.playAt(level(), position(), "tormentor_r", 1.5F);
                }
                setDeltaMovement(dir.x * 0.17, getDeltaMovement().y, dir.z * 0.17);
                StalkerUtil.face(this, position().add(dir));
                if (stateTicks >= 75) discard();
                return;
            }
            for (ServerPlayer p : StalkerUtil.playersNear(level(), position(), 64)) {
                if (distanceTo(p) <= 1.5F) {
                    StalkerUtil.kill(p);
                    StalkerUtil.playAt(level(), p.position(), "j_tormentor", 10.0F);
                    discard(); return;
                }
                if (StalkerUtil.looking(p, this, 0.60)) { discard(); return; }
            }
        }
        @Override protected String animationFor(int s, boolean m) {
            return s == 1 ? "animation.tormentor.t_run" : "animation.tormentor.t_door";
        }
    }

    /** 0 idle en la puerta, 1 mira, 2 ventana, 3 rompe, 4 corre. */
    public static class TormentorDoor extends StalkerEntity {
        private Vec3 doorPos;
        private boolean init;
        public TormentorDoor(EntityType<? extends StalkerEntity> t, Level l) { super(t, l); makeStatic(); maxLife = 3000; }

        private boolean anyLooks() {
            for (ServerPlayer p : StalkerUtil.playersNear(level(), position(), 128))
                if (StalkerUtil.looking(p, this, 0.4)) return true;
            return false;
        }
        @Override protected void serverBehavior() {
            if (!init) {
                init = true;
                BlockPos d = StalkerUtil.nearestBlock(level(), position(), 5, 2, 5, StalkerUtil::isDoor);
                if (d != null) doorPos = Vec3.atCenterOf(d);
            }
            ServerPlayer p = nearest(128);
            switch (getState()) {
                case 0 -> {
                    if (stateTicks % 100 == 0) StalkerUtil.playAt(level(), position(), "outside", 1.5F);
                    if (p != null) face(p); else if (doorPos != null) StalkerUtil.face(this, doorPos);
                    if (stateTicks >= 600) { discard(); return; }
                    if (anyLooks()) { setState(1); StalkerUtil.playAt(level(), position(), "look_s_d", 3.5F); }
                }
                case 1 -> {
                    if (p != null) face(p);
                    if (stateTicks >= 140) {
                        BlockPos w = StalkerUtil.findBlock(level(), blockPosition(), 6, 2, 6, 2,
                                s -> StalkerUtil.isGlass(s));
                        if (w != null) { setPos(Vec3.atBottomCenterOf(w)); setState(2); } else discard();
                    }
                }
                case 2 -> {
                    if (p != null) face(p);
                    if (stateTicks >= 400) { discard(); return; }
                    if (anyLooks()) setState(3);
                }
                case 3 -> {
                    if (p != null) face(p);
                    if (stateTicks == 180) StalkerUtil.breakGlass(level(), blockPosition(), 1, 0, 1, 1);
                    if (stateTicks >= 200) {
                        setState(4);
                        for (ServerPlayer q : StalkerUtil.playersNear(level(), position(), 128)) StalkerUtil.playLocal(q, "w_tdr", 2.5F);
                    }
                }
                default -> {
                    if (stateTicks >= 600) { discard(); return; }
                    if (p == null) return;
                    stepToward(p, 0.25, true);
                    double dx = p.getX() - getX(), dz = p.getZ() - getZ();
                    if (Math.hypot(dx, dz) < 1.8) { StalkerUtil.kill(p); StalkerUtil.stopAll(sl()); discard(); }
                }
            }
        }
        @Override protected String animationFor(int s, boolean m) {
            return switch (s) { case 1 -> "animation.tormentor_door.stalk_door"; case 2 -> "animation.tormentor_door.tdr_window";
                case 3 -> "animation.tormentor_door.broke_window_t"; case 4 -> "animation.tormentor_door.tdr_run";
                default -> "animation.tormentor_door.tdr_idle"; };
        }
    }

    /** 0 idle, 1 persigue por teletransporte (3.5 bloques cada 2 ticks), 2 jumpscare. */
    public static class TormentorHole extends StalkerEntity {
        public TormentorHole(EntityType<? extends StalkerEntity> t, Level l) { super(t, l); makeStatic(); maxLife = 1500; }
        @Override protected void serverBehavior() {
            ServerPlayer p = nearest(128);
            if (p == null) return;
            if (getState() == 0) {
                face(p);
                if (stateTicks >= 200) {
                    setState(1);
                    StalkerUtil.playAt(level(), position(), "j_tormentor", 4.0F);
                }
            } else if (getState() == 1) {
                if (tickCount % 2 == 0) stepToward(p, 3.5, true);
                if (distanceTo(p) <= 2.2F) { setState(2); StalkerUtil.kill(p); discard(); return; }
                if (stateTicks >= 800) discard();
            }
        }
        @Override protected String animationFor(int s, boolean m) {
            return s == 0 ? "animation.tormentor_hole.idle_th" : s == 1 ? "animation.tormentor_hole.chase_th" : "animation.tormentor_hole.jumpscare_th";
        }
    }
}
