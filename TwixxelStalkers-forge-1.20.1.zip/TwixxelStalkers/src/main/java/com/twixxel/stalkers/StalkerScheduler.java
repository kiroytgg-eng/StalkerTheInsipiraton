package com.twixxel.stalkers;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Equivalente a system.runTimeout() de Bedrock (se ejecuta en el hilo del servidor). */
public final class StalkerScheduler {
    private static final class Task {
        int left; final Runnable run;
        Task(int left, Runnable run) { this.left = left; this.run = run; }
    }
    private static final List<Task> TASKS = new ArrayList<>();
    private static final List<Task> PENDING = new ArrayList<>();

    public static void runLater(int ticks, Runnable r) { PENDING.add(new Task(Math.max(1, ticks), r)); }

    public static void tick() {
        TASKS.addAll(PENDING);
        PENDING.clear();
        Iterator<Task> it = TASKS.iterator();
        List<Runnable> due = new ArrayList<>();
        while (it.hasNext()) {
            Task t = it.next();
            if (--t.left <= 0) { due.add(t.run); it.remove(); }
        }
        for (Runnable r : due) {
            try { r.run(); } catch (Exception ignored) { }
        }
    }

    public static void clear() { TASKS.clear(); PENDING.clear(); }

    private StalkerScheduler() {}
}
