package com.twixxel.stalkers.client;

import com.twixxel.stalkers.TwixxelStalkers;
import com.twixxel.stalkers.entity.StalkerEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class StalkerModel<T extends StalkerEntity> extends GeoModel<T> {
    private final ResourceLocation model, texture, anim;
    public StalkerModel(String id) {
        model = new ResourceLocation(TwixxelStalkers.MODID, "geo/" + id + ".geo.json");
        texture = new ResourceLocation(TwixxelStalkers.MODID, "textures/entity/" + id + ".png");
        anim = new ResourceLocation(TwixxelStalkers.MODID, "animations/" + id + ".animation.json");
    }
    @Override public ResourceLocation getModelResource(T a) { return model; }
    @Override public ResourceLocation getTextureResource(T a) { return texture; }
    @Override public ResourceLocation getAnimationResource(T a) { return anim; }
}
