package com.twixxel.stalkers.entity;

import com.twixxel.stalkers.util.StalkerUtil;
import java.util.EnumSet;
import java.util.function.Consumer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.OpenDoorGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** stalker_chase y cave_stalker_chase: usaban IA nativa de Bedrock (melee_attack + nearest_attackable_target). */
public final class NativeMobs {
    private NativeMobs() {}

    static class KillGoal extends Goal {
        private final PathfinderMob mob; private final double speed, range; private final Consumer<ServerPlayer> onCatch;
        KillGoal(PathfinderMob mob, double speed, double range, Consumer<ServerPlayer> onCatch) {
            this.mob = mob; this.speed = speed; this.range = range; this.onCatch = onCatch;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }
        @Override public boolean canUse() { LivingEntity t = mob.getTarget(); return t != null && t.isAlive(); }
        @Override public void tick() {
            LivingEntity t = mob.getTarget();
            if (t == null) return;
            mob.getLookControl().setLookAt(t, 30F, 30F);
            mob.getNavigation().moveTo(t, speed);
            if (mob.distanceToSqr(t) <= range * range && t instanceof ServerPlayer p) onCatch.accept(p);
        }
        @Override public void stop() { mob.getNavigation().stop(); }
    }

    private abstract static class ChaseBase extends StalkerEntity {
        protected ChaseBase(EntityType<? extends StalkerEntity> t, Level l) {
            super(t, l);
            maxLife = 0;
            if (getNavigation() instanceof GroundPathNavigation g) { g.setCanOpenDoors(true); g.setCanFloat(true); }
        }
        protected void addTargetGoals() {
            targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, 5, false, false,
                    e -> e instanceof Player p && StalkerUtil.validTarget(p)));
        }
    }

    public static class StalkerChase extends ChaseBase {
        private boolean announced;
        public StalkerChase(EntityType<? extends StalkerEntity> t, Level l) { super(t, l); }
        @Override protected void registerGoals() {
            goalSelector.addGoal(0, new FloatGoal(this));
            goalSelector.addGoal(1, new OpenDoorGoal(this, false));
            goalSelector.addGoal(2, new KillGoal(this, 1.0, 3.0, p -> {
                StalkerUtil.jumpscareGlyph(p);
                StalkerUtil.playLocal(p, "jumpscare_staller_chase", 5.0F);
                StalkerUtil.kill(p);
                discard();
            }));
            addTargetGoals();
        }
        @Override protected void serverBehavior() {
            if (!announced) {
                announced = true;
                StalkerUtil.playAt(level(), position(), "chasing_stalker", 7.5F);
                for (ServerPlayer p : StalkerUtil.playersNear(level(), position(), 120))
                    p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 1200, 1, false, true));
            }
        }
        @Override protected String animationFor(int s, boolean m) { return "animation.stalker_chase"; }
    }

    public static class CaveStalkerChase extends ChaseBase {
        public CaveStalkerChase(EntityType<? extends StalkerEntity> t, Level l) { super(t, l); }
        @Override protected void registerGoals() {
            goalSelector.addGoal(0, new FloatGoal(this));
            goalSelector.addGoal(1, new OpenDoorGoal(this, false));
            goalSelector.addGoal(2, new KillGoal(this, 1.0, 1.8, p -> {
                for (ServerPlayer q : StalkerUtil.playersNear(level(), position(), 15))
                    StalkerUtil.playLocal(q, "jumpscare_staller_chase", 1.0F);
                StalkerUtil.kill(p);
                discard();
            }));
            goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 120F));
            addTargetGoals();
        }
        @Override protected void serverBehavior() { }
        @Override protected String animationFor(int s, boolean m) { return "animation.cave_stalker_chase.c_run"; }
    }
}
