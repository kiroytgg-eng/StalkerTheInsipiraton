package com.twixxel.stalkers;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.twixxel.stalkers.entity.StalkerEntity;
import com.twixxel.stalkers.util.StalkerUtil;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.server.ServerLifecycleHooks;

public final class StalkerEvents {
    private StalkerEvents() {}

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        StalkerScheduler.tick();
        var server = ServerLifecycleHooks.getCurrentServer();
        if (server != null) StalkerSpawner.tick(server);
    }

    /** Equivale a world.afterEvents.entityDie del main.js. */
    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || !StalkerConfig.DEATH_SOUND.get()) return;
        ServerLevel lvl = p.serverLevel();
        StalkerUtil.stopForAll(lvl, "look_c_stalker");
        StalkerUtil.stopForAll(lvl, "running_td");
        StalkerUtil.playAt(lvl, p.position(), "custom_player_death", 1.0F);
    }

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) {
        CommandDispatcher<CommandSourceStack> d = e.getDispatcher();
        LiteralArgumentBuilder<CommandSourceStack> root = Commands.literal("stalkers").requires(s -> s.hasPermission(2));
        root.then(Commands.literal("list").executes(c -> {
            c.getSource().sendSuccess(() -> Component.literal(String.join(", ", ModEntities.DEFS.keySet())), false);
            return 1;
        }));
        root.then(Commands.literal("clear").executes(c -> {
            int n = 0;
            for (Entity en : c.getSource().getLevel().getAllEntities()) if (en instanceof StalkerEntity) { en.discard(); n++; }
            final int f = n;
            c.getSource().sendSuccess(() -> Component.literal("Eliminados: " + f), true);
            return n;
        }));
        root.then(Commands.literal("spawn").then(Commands.argument("mob", StringArgumentType.word())
                .suggests((ctx, b) -> { ModEntities.DEFS.keySet().forEach(b::suggest); return b.buildFuture(); })
                .executes(c -> {
                    String id = StringArgumentType.getString(c, "mob");
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    ServerLevel lvl = p.serverLevel();
                    if (!ModEntities.DEFS.containsKey(id)) { c.getSource().sendFailure(Component.literal("Mob desconocido: " + id)); return 0; }
                    switch (id) {
                        case "evil_hunt" -> StalkerSpawner.spawnEvilHunt(p);
                        case "raro" -> StalkerSpawner.spawnRaroNearTree(lvl, p);
                        case "tormentor_hole" -> StalkerSpawner.spawnTormentorHole(lvl, p);
                        default -> {
                            Vec3 g = StalkerUtil.findGround(lvl, p.getX() + 2, p.getY(), p.getZ() + 2);
                            StalkerSpawner.spawn(lvl, id, g != null ? g : p.position().add(2, 0, 2));
                        }
                    }
                    c.getSource().sendSuccess(() -> Component.literal("Invocado: " + id), true);
                    return 1;
                })));
        d.register(root);
    }
}
