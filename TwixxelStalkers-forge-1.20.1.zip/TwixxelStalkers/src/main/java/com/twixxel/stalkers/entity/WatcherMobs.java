package com.twixxel.stalkers.entity;

import com.twixxel.stalkers.util.StalkerUtil;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

/** Mobs quietos que observan: stalker1, stalker2, stalker4, tormentor_m, cave_stalker_up. */
public final class WatcherMobs {
    private WatcherMobs() {}

    public abstract static class Watcher extends StalkerEntity {
        private final String sound, idleAnim, hideAnim;
        private final boolean soundOnSpawn;
        private final double lookDot;
        private final int lookNeeded, hideDelay, unseenLimit;
        private final double range;
        private int lookTicks, unseen;
        private boolean soundPlayed;

        protected Watcher(EntityType<? extends StalkerEntity> t, Level l, String sound, boolean soundOnSpawn,
                          double lookDot, int lookNeeded, int hideDelay, int maxLife, int unseenLimit,
                          double range, String idleAnim, String hideAnim) {
            super(t, l);
            this.sound = sound; this.soundOnSpawn = soundOnSpawn; this.lookDot = lookDot;
            this.lookNeeded = lookNeeded; this.hideDelay = hideDelay; this.unseenLimit = unseenLimit;
            this.range = range; this.idleAnim = idleAnim; this.hideAnim = hideAnim;
            this.maxLife = maxLife;
            makeStatic();
        }

        @Override
        protected void serverBehavior() {
            ServerPlayer p = nearest(range);
            if (p == null) return;
            face(p);
            if (getState() == 1) {
                if (stateTicks >= hideDelay) discard();
                return;
            }
            if (soundOnSpawn && !soundPlayed) {
                soundPlayed = true;
                StalkerUtil.playLocal(p, sound, 1.5F);
            }
            if (StalkerUtil.looking(p, this, lookDot)) {
                unseen = 0;
                if (!soundOnSpawn && !soundPlayed) {
                    soundPlayed = true;
                    StalkerUtil.playAt(level(), position(), sound, 2.0F);
                }
                if (++lookTicks >= lookNeeded) {
                    setState(1);
                    if (soundOnSpawn) StalkerUtil.stopLocal(p, sound);
                }
            } else if (unseenLimit > 0 && ++unseen >= unseenLimit) {
                StalkerUtil.stopLocal(p, sound);
                discard();
            }
        }

        @Override
        protected String animationFor(int state, boolean moving) { return state == 0 ? idleAnim : hideAnim; }
    }

    public static class Stalker1 extends Watcher {
        public Stalker1(EntityType<? extends StalkerEntity> t, Level l) {
            super(t, l, "stalker1", false, 0.80, 100, 5, 1400, 0, 256,
                    "animation.stalker1.s1_idle", "animation.stalker1.s1_hide");
        }
    }

    public static class Stalker2 extends Watcher {
        public Stalker2(EntityType<? extends StalkerEntity> t, Level l) {
            super(t, l, "stalker2", false, 0.80, 100, 5, 1400, 0, 256,
                    "animation.stalker2.s2_idle", "animation.stalker2.s2_hide");
        }
    }

    public static class Stalker4 extends Watcher {
        public Stalker4(EntityType<? extends StalkerEntity> t, Level l) {
            super(t, l, "look_s_d", true, 0.75, 1, 25, 0, 400, 22,
                    "animation.stalker4.s4_idle", "animation.stalker4.s4_hide");
            this.maxLife = 12000;
        }
    }

    /** Se queda quieto a <=15 bloques; si lo miras ~4 s desaparece. */
    public static class TormentorM extends StalkerEntity {
        private int timer;
        private boolean soundPlayed;
        public TormentorM(EntityType<? extends StalkerEntity> t, Level l) { super(t, l); makeStatic(); maxLife = 6000; }

        @Override
        protected void serverBehavior() {
            ServerPlayer p = nearest(15);
            if (p == null) return;
            face(p);
            if (StalkerUtil.looking(p, this, 0.85)) {
                if (!soundPlayed) { soundPlayed = true; StalkerUtil.playLocal(p, "pf", 2.0F); }
                if (++timer >= 80) { StalkerUtil.stopLocal(p, "pf"); discard(); }
            }
        }
        @Override protected String animationFor(int s, boolean m) { return "animation.tormentor_m.tm_idle"; }
    }

    public static class CaveStalkerUp extends StalkerEntity {
        public CaveStalkerUp(EntityType<? extends StalkerEntity> t, Level l) { super(t, l); makeStatic(); maxLife = 400; }
        @Override protected void serverBehavior() {
            ServerPlayer p = nearest(64);
            if (p != null) face(p);
        }
        @Override protected String animationFor(int s, boolean m) { return "animation.cave_stalker_up.cup_hide"; }
    }
}
