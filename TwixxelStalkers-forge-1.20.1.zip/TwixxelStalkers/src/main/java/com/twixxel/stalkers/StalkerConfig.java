package com.twixxel.stalkers;

import net.minecraftforge.common.ForgeConfigSpec;

public final class StalkerConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue NATURAL_SPAWNING;
    public static final ForgeConfigSpec.DoubleValue SPAWN_MULTIPLIER;
    public static final ForgeConfigSpec.BooleanValue AFFECT_CREATIVE;
    public static final ForgeConfigSpec.BooleanValue DEATH_SOUND;
    public static final ForgeConfigSpec.BooleanValue USE_ACTIVE_CYCLE;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        NATURAL_SPAWNING = b.comment("Aparicion natural de los stalkers (los scripts originales).")
                .define("naturalSpawning", true);
        SPAWN_MULTIPLIER = b.comment("Multiplicador de las probabilidades de aparicion (1.0 = igual que el addon).")
                .defineInRange("spawnChanceMultiplier", 1.0D, 0.0D, 100.0D);
        AFFECT_CREATIVE = b.comment("Si es false, los stalkers ignoran a jugadores en creativo/espectador.")
                .define("affectCreativePlayers", false);
        DEATH_SOUND = b.comment("Reproduce 'custom_player_death' cuando muere un jugador (como el addon).")
                .define("playDeathSound", true);
        USE_ACTIVE_CYCLE = b.comment("Ciclo 7 min activo / 7 min inactivo. El addon lo calculaba pero ningun mob lo usaba; por eso esta desactivado.")
                .define("useActiveCycle", false);
        SPEC = b.build();
    }

    private StalkerConfig() {}
}
