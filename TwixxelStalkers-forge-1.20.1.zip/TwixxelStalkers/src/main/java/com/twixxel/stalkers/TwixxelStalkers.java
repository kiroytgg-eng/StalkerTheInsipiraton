package com.twixxel.stalkers;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.eventbus.api.IEventBus;

@Mod(TwixxelStalkers.MODID)
public class TwixxelStalkers {
    public static final String MODID = "twixxel_stalkers";

    public TwixxelStalkers() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITIES.register(bus);
        ModEntities.ITEMS.register(bus);
        ModSounds.SOUNDS.register(bus);
        bus.addListener(ModEntities::onAttributes);
        bus.addListener(ModEntities::onCreativeTab);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, StalkerConfig.SPEC);
        MinecraftForge.EVENT_BUS.register(StalkerEvents.class);
    }
}
