package com.twixxel.stalkers.entity;

import com.twixxel.stalkers.ModEntities;
import com.twixxel.stalkers.util.StalkerUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.Animation;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Base de todos los mobs del addon. Lo que en Bedrock eran "tags + dynamic properties + scripts"
 * aqui es una maquina de estados sincronizada (DATA_STATE) que tambien elige la animacion en el cliente.
 */
public abstract class StalkerEntity extends PathfinderMob implements GeoEntity {
    protected static final EntityDataAccessor<Integer> DATA_STATE =
            SynchedEntityData.defineId(StalkerEntity.class, EntityDataSerializers.INT);

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    /** ticks desde el ultimo cambio de estado */
    protected int stateTicks;
    /** ticks de vida (seguridad: ningun mob se queda para siempre) */
    protected int life;
    protected int maxLife = 6000;
    private float visualScale = 1.0F;

    protected StalkerEntity(EntityType<? extends StalkerEntity> type, Level level) {
        super(type, level);
        this.xpReward = 0;
        setMaxUpStep(1.1F);
        setPersistenceRequired();
        var key = ForgeRegistries.ENTITY_TYPES.getKey(type);
        if (key != null) this.visualScale = ModEntities.scaleOf(key.getPath());
    }

    public static AttributeSupplier.Builder attributes(double speed) {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 100.0D)
                .add(Attributes.MOVEMENT_SPEED, speed)
                .add(Attributes.FOLLOW_RANGE, 128.0D)
                .add(Attributes.ATTACK_DAMAGE, 1.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D);
    }

    // ------------------------------------------------------------------ estado
    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_STATE, 0);
    }

    public int getState() { return this.entityData.get(DATA_STATE); }

    public void setState(int s) {
        if (getState() != s) {
            this.entityData.set(DATA_STATE, s);
            this.stateTicks = 0;
            onStateChanged(s);
        }
    }

    protected void onStateChanged(int newState) { }

    /** @return nombre de la animacion (ej. "animation.stalker1.s1_idle") o null para ninguna. */
    protected abstract String animationFor(int state, boolean moving);

    /** Logica del servidor, se llama 1 vez por tick. */
    protected abstract void serverBehavior();

    // ------------------------------------------------------------------ tick
    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide) {
            this.life++;
            this.stateTicks++;
            if (this.maxLife > 0 && this.life > this.maxLife) { discard(); return; }
            serverBehavior();
        }
    }

    protected ServerLevel sl() { return (ServerLevel) this.level(); }

    protected ServerPlayer nearest(double max) { return StalkerUtil.nearestPlayer(this, max); }

    protected void face(Entity target) { StalkerUtil.face(this, target.position()); }

    /** Para mobs que solo se teletransportan/estan quietos. */
    protected void makeStatic() {
        this.noPhysics = true;
        setNoGravity(true);
    }

    protected void makeSolid() {
        this.noPhysics = false;
        setNoGravity(false);
    }

    /** Equivale al applyImpulse(dir*k - vel*0.5) de los scripts, pero con velocidad horizontal objetivo (bloques/tick). */
    protected void chase(Entity target, double speed, double jump) {
        Vec3 d = target.position().subtract(position());
        double hd = Math.hypot(d.x, d.z);
        if (hd < 1.0E-4D) return;
        double dx = d.x / hd, dz = d.z / hd;
        double vy = getDeltaMovement().y;
        if (onGround()) {
            BlockPos ahead = BlockPos.containing(getX() + dx * 0.8D, getY(), getZ() + dz * 0.8D);
            boolean blocked = !level().getBlockState(ahead).getCollisionShape(level(), ahead).isEmpty()
                    || !level().getBlockState(ahead.above()).getCollisionShape(level(), ahead.above()).isEmpty();
            if (blocked || target.getY() > getY() + 0.5D) vy = jump;
        }
        setDeltaMovement(dx * speed, vy, dz * speed);
        this.hasImpulse = true;
        StalkerUtil.face(this, target.position());
    }

    /** Avance por teletransporte (evil_hunt, tormentor_door...). */
    protected void stepToward(Entity target, double step, boolean keepY) {
        Vec3 d = target.position().subtract(position());
        double hd = Math.hypot(d.x, d.z);
        if (hd < 1.0E-4D) return;
        double nx = getX() + d.x / hd * step;
        double nz = getZ() + d.z / hd * step;
        setPos(nx, keepY ? getY() : target.getY(), nz);
        setDeltaMovement(Vec3.ZERO);
        StalkerUtil.face(this, target.position());
    }

    protected void damageNearbyPlayers(double radius) {
        for (ServerPlayer p : StalkerUtil.playersNear(level(), position(), radius)) StalkerUtil.kill(p);
    }

    // ------------------------------------------------------------------ comportamiento "inerte"
    @Override public boolean isInvulnerableTo(DamageSource src) { return !src.is(DamageTypeTags.BYPASSES_INVULNERABILITY); }
    @Override public boolean isPushable() { return false; }
    @Override public void push(Entity e) { }
    @Override protected void doPush(Entity e) { }
    @Override public boolean canBeCollidedWith() { return false; }
    @Override public boolean isPickable() { return false; }
    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override public boolean fireImmune() { return true; }
    @Override public boolean canBeLeashed(net.minecraft.world.entity.player.Player p) { return false; }
    @Override protected void playStepSound(BlockPos pos, BlockState state) { }
    @Override protected boolean shouldDropLoot() { return false; }

    @Override
    public AABB getBoundingBoxForCulling() { return getBoundingBox().inflate(3.0D * this.visualScale); }

    // ------------------------------------------------------------------ NBT
    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("StalkerState", getState());
        tag.putInt("StalkerLife", this.life);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("StalkerState")) this.entityData.set(DATA_STATE, tag.getInt("StalkerState"));
        this.life = tag.getInt("StalkerLife");
    }

    // ------------------------------------------------------------------ GeckoLib
    private boolean movedRecently() {
        double dx = getX() - this.xo, dz = getZ() - this.zo;
        return dx * dx + dz * dz > 1.0E-4D;
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 3, this::animate));
    }

    private PlayState animate(AnimationState<StalkerEntity> state) {
        String anim = animationFor(getState(), movedRecently());
        if (anim == null) return PlayState.STOP;
        return state.setAndContinue(RawAnimation.begin().then(anim, Animation.LoopType.DEFAULT));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return this.cache; }
}
