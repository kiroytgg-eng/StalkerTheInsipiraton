package com.twixxel.stalkers;

import com.twixxel.stalkers.entity.*;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, TwixxelStalkers.MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, TwixxelStalkers.MODID);

    /** w/h = collision_box del addon, scale = minecraft:scale, speed = atributo de movimiento (solo IA nativa). */
    public record Def(String id, float w, float h, float scale, double speed) {}

    public static final Map<String, Def> DEFS = new LinkedHashMap<>();
    @SuppressWarnings("rawtypes")
    public static final Map<String, RegistryObject<EntityType<?>>> TYPES = new LinkedHashMap<>();

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static <T extends StalkerEntity> void reg(String id, EntityType.EntityFactory<T> f, float w, float h, float scale, double speed) {
        DEFS.put(id, new Def(id, w, h, scale, speed));
        RegistryObject<EntityType<T>> ro = ENTITIES.register(id, () -> EntityType.Builder.of(f, MobCategory.MONSTER)
                .sized(Math.max(w, 0.05F), Math.max(h, 0.05F)).clientTrackingRange(12).updateInterval(1).fireImmune()
                .build(TwixxelStalkers.MODID + ":" + id));
        TYPES.put(id, (RegistryObject) ro);
        ITEMS.register(id + "_spawn_egg", () -> new ForgeSpawnEggItem(ro, 0x151515, 0x8B0000, new Item.Properties()));
    }

    static {
        reg("stalker1", WatcherMobs.Stalker1::new, .025F, .025F, 5F, .3);
        reg("stalker2", WatcherMobs.Stalker2::new, .025F, .025F, 5F, .3);
        reg("stalker3", ChaserMobs.Stalker3::new, .005F, .005F, 5F, .3);
        reg("stalker4", WatcherMobs.Stalker4::new, .001F, .001F, 5F, .3);
        reg("stalker_bed", TrapMobs.StalkerBed::new, .025F, .025F, 4.5F, .3);
        reg("stalker_up", TrapMobs.StalkerUp::new, .025F, .025F, 5F, .3);
        reg("stalker_chase", NativeMobs.StalkerChase::new, .025F, .025F, 3.3F, .42);
        reg("stalker_door_2", DoorMobs.StalkerDoor2::new, .025F, .025F, 7.5F, .3);
        reg("stalker_door_3", DoorMobs.StalkerDoor3::new, .026F, .028F, 6.5F, .3);
        reg("c_stalker", ChaserMobs.CStalker::new, .025F, .025F, 7F, .3);
        reg("c_stalker_bed", TrapMobs.CStalkerBed::new, .025F, .025F, 7F, .3);
        reg("cave_stalker", TrapMobs.CaveStalker::new, .025F, .025F, 3.3F, .3);
        reg("cave_stalker_chase", NativeMobs.CaveStalkerChase::new, .055F, .055F, 5.5F, .34);
        reg("cave_stalker_up", WatcherMobs.CaveStalkerUp::new, .6F, 1.8F, 2F, .3);
        reg("evil_hunt", ChaserMobs.EvilHunt::new, .026F, .025F, 6.5F, .3);
        reg("hunt", ChaserMobs.Hunt::new, .001F, .001F, 4.5F, .3);
        reg("ice_stalker", ChaserMobs.IceStalker::new, .001F, .001F, 7F, .3);
        reg("raro", ChaserMobs.Raro::new, .025F, .025F, 2F, .3);
        reg("silent", ChaserMobs.Silent::new, .026F, .028F, 5.5F, .3);
        reg("silent_door", DoorMobs.SilentDoor::new, .001F, .001F, 4F, .3);
        reg("something", ChaserMobs.Something::new, .026F, .025F, 4.5F, .3);
        reg("tormentor", DoorMobs.Tormentor::new, .025F, .025F, 6F, .3);
        reg("tormentor_door", DoorMobs.TormentorDoor::new, .025F, .025F, 6.5F, .3);
        reg("tormentor_hole", DoorMobs.TormentorHole::new, .025F, .025F, 4.5F, .3);
        reg("tormentor_m", WatcherMobs.TormentorM::new, .006F, .008F, 3F, .3);
        reg("tortured", ChaserMobs.Tortured::new, .025F, .025F, 4F, .3);
        reg("tree_stalker", TrapMobs.TreeStalker::new, .025F, .025F, 5F, .3);
        reg("yelling_creature", ChaserMobs.YellingCreature::new, .001F, .001F, 5F, .3);
    }

    public static float scaleOf(String id) { Def d = DEFS.get(id); return d == null ? 1F : d.scale(); }

    public static EntityType<?> type(String id) { RegistryObject<EntityType<?>> r = TYPES.get(id); return r == null ? null : r.get(); }

    public static void onAttributes(EntityAttributeCreationEvent e) {
        for (Map.Entry<String, RegistryObject<EntityType<?>>> en : TYPES.entrySet()) {
            @SuppressWarnings("unchecked")
            EntityType<? extends LivingEntity> t = (EntityType<? extends LivingEntity>) en.getValue().get();
            e.put(t, StalkerEntity.attributes(DEFS.get(en.getKey()).speed()).build());
        }
    }

    public static void onCreativeTab(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.SPAWN_EGGS) ITEMS.getEntries().forEach(e::accept);
    }

    private ModEntities() {}
}
