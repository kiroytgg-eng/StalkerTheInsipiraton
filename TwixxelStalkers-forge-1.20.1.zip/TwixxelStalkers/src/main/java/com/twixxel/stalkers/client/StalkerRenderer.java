package com.twixxel.stalkers.client;

import com.twixxel.stalkers.entity.StalkerEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class StalkerRenderer<T extends StalkerEntity> extends GeoEntityRenderer<T> {
    public StalkerRenderer(EntityRendererProvider.Context ctx, String id, float scale) {
        super(ctx, new StalkerModel<>(id));
        this.shadowRadius = 0.0F;
        withScale(scale);
    }
}
