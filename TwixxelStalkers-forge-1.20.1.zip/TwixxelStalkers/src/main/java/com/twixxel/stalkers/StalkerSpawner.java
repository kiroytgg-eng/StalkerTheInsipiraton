package com.twixxel.stalkers;

import com.twixxel.stalkers.entity.*;
import com.twixxel.stalkers.util.StalkerUtil;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.Random;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/** Port de la logica de aparicion de todos los scripts (intervalos y probabilidades originales). */
public final class StalkerSpawner {
    private StalkerSpawner() {}

    private static final Random R = new Random();

    private static final class PS {
        Vec3 lastPos = Vec3.ZERO; int idle, stone, noSky, doorSpawn, tdTimer; boolean sleeping;
        final Map<String, Long> cd = new HashMap<>();
    }
    private static final Map<UUID, PS> STATE = new HashMap<>();

    // ------------------------------------------------------------------ API
    public static StalkerEntity spawn(ServerLevel lvl, String id, Vec3 pos) {
        EntityType<?> t = ModEntities.type(id);
        if (t == null) return null;
        Entity e = t.create(lvl);
        if (!(e instanceof StalkerEntity s)) return null;
        s.moveTo(pos.x, pos.y, pos.z, R.nextFloat() * 360F, 0F);
        lvl.addFreshEntity(s);
        return s;
    }

    private static StalkerEntity spawnFacing(ServerLevel lvl, String id, Vec3 pos, ServerPlayer p) {
        StalkerEntity s = spawn(lvl, id, pos);
        if (s != null && p != null) StalkerUtil.face(s, p.position());
        return s;
    }

    private static boolean chance(double p) { return R.nextDouble() < p * StalkerConfig.SPAWN_MULTIPLIER.get(); }

    private static boolean exists(ServerLevel lvl, String id, Vec3 pos, double r) {
        EntityType<?> t = ModEntities.type(id);
        return !lvl.getEntities(t, StalkerUtil.around(pos, r), e -> true).isEmpty();
    }

    private static boolean existsAnywhere(ServerLevel lvl, String id) {
        EntityType<?> t = ModEntities.type(id);
        for (Entity e : lvl.getAllEntities()) if (e.getType() == t) return true;
        return false;
    }

    private static Vec3 ring(ServerPlayer p, double min, double max) {
        double a = R.nextDouble() * Math.PI * 2, d = min + R.nextDouble() * (max - min);
        return new Vec3(p.getX() + Math.cos(a) * d, p.getY(), p.getZ() + Math.sin(a) * d);
    }

    /** Ring + ajuste al suelo. */
    private static boolean ringSpawn(ServerLevel lvl, ServerPlayer p, String id, double min, double max) {
        Vec3 r = ring(p, min, max);
        Vec3 g = StalkerUtil.findGround(lvl, r.x, r.y, r.z);
        if (g == null) return false;
        return spawnFacing(lvl, id, g, p) != null;
    }

    private static boolean cooldownReady(PS s, String key, long now) { Long n = s.cd.get(key); return n == null || now >= n; }

    private static boolean onStone(ServerLevel lvl, ServerPlayer p) {
        BlockPos b = p.blockPosition().below();
        return lvl.getBlockState(b).is(Blocks.STONE);
    }

    private static BlockPos doorNear(ServerLevel lvl, ServerPlayer p, int r, int step) {
        return StalkerUtil.findBlock(lvl, p.blockPosition(), r, 2, r, step, StalkerUtil::isDoor);
    }

    private static Vec3 doorCenter(ServerLevel lvl, BlockPos d) {
        BlockState s = lvl.getBlockState(d);
        for (BlockPos n : new BlockPos[]{d.east(), d.west(), d.north(), d.south()}) {
            if (lvl.getBlockState(n).getBlock() == s.getBlock()) {
                return new Vec3((d.getX() + n.getX()) / 2.0 + 0.5, d.getY(), (d.getZ() + n.getZ()) / 2.0 + 0.5);
            }
        }
        return Vec3.atBottomCenterOf(d);
    }

    // ------------------------------------------------------------------ tick
    private static long cycleTicks;
    public static boolean cycleActive() { return cycleTicks % 16800 < 8400; }

    public static void tick(MinecraftServer server) {
        cycleTicks++;
        if (!StalkerConfig.NATURAL_SPAWNING.get()) return;
        if (StalkerConfig.USE_ACTIVE_CYCLE.get() && !cycleActive()) return;
        long t = server.getTickCount();
        List<ServerPlayer> players = server.getPlayerList().getPlayers();
        for (ServerPlayer p : players) {
            if (!StalkerUtil.validTarget(p)) continue;
            ServerLevel lvl = p.serverLevel();
            PS s = STATE.computeIfAbsent(p.getUUID(), k -> new PS());
            boolean ow = lvl.dimension() == Level.OVERWORLD;
            try { perPlayer(t, p, lvl, s, ow); } catch (Exception ex) { /* un mal bloque no debe tumbar el servidor */ }
        }
        if (t % 2400 == 0 && R.nextDouble() < 0.05 * StalkerConfig.SPAWN_MULTIPLIER.get() && !players.isEmpty()) {
            ServerPlayer rp = players.get(R.nextInt(players.size()));
            if (rp.serverLevel().dimension() == Level.OVERWORLD && StalkerUtil.validTarget(rp)) spawnEvilHunt(rp);
        }
        if (t % 2000 == 0 && chance(0.15)) {
            for (ServerPlayer p : players) {
                if (!StalkerUtil.validTarget(p) || p.serverLevel().dimension() != Level.OVERWORLD) continue;
                if (spawnTormentor(p.serverLevel(), p)) break;
            }
        }
        if (t % 6000 == 0 && chance(0.10)) {
            for (ServerPlayer p : players) {
                if (!StalkerUtil.validTarget(p) || p.serverLevel().dimension() != Level.OVERWORLD) continue;
                if (spawnTortured(p.serverLevel(), p)) break;
            }
        }
    }

    private static void perPlayer(long t, ServerPlayer p, ServerLevel lvl, PS s, boolean ow) {
        Vec3 pos = p.position();
        // --- contadores cada 20 ticks
        if (t % 20 == 0) {
            if (pos.distanceToSqr(s.lastPos) < 0.01) s.idle += 20; else s.idle = 0;
            s.lastPos = pos;
            if (s.idle >= 700) { s.idle = 0; spawn(lvl, "stalker_up", pos); }
            s.stone = onStone(lvl, p) ? s.stone + 1 : 0;
            s.noSky = StalkerUtil.skyLight(lvl, p.blockPosition()) == 0 ? s.noSky + 20 : 0;
            s.doorSpawn += 20;
        }
        // --- dormir
        if (t % 10 == 0) {
            boolean sl = p.isSleeping();
            if (sl && !s.sleeping && chance(0.15) && !exists(lvl, "stalker_bed", pos, 10)) {
                double yaw = Math.toRadians(p.getYRot());
                Vec3 sp = new Vec3(pos.x - Math.sin(yaw) * 2, pos.y, pos.z + Math.cos(yaw) * 2);
                if (StalkerUtil.solidAt(lvl, sp.x, sp.y, sp.z)) sp = pos;
                StalkerEntity e = spawn(lvl, "stalker_bed", sp);
                if (e instanceof TrapMobs.StalkerBed b) b.start(p);
            }
            s.sleeping = sl;
        }
        // --- watchers (cooldown largo)
        if (t % 40 == 0) {
            if (cooldownReady(s, "stalker1", t) && chance(0.20) && ringSpawn(lvl, p, "stalker1", 18, 25)) s.cd.put("stalker1", t + 32000);
            if (cooldownReady(s, "stalker2", t) && chance(0.20) && ringSpawn(lvl, p, "stalker2", 18, 25)) s.cd.put("stalker2", t + 32000);
            if (chance(0.01)) { spawnAtDist(lvl, p, "hunt", 10); }
            if (cooldownReady(s, "stalker3", t) && !exists(lvl, "stalker3", pos, 30) && chance(0.01)
                    && ringSpawn(lvl, p, "stalker3", 15, 15)) s.cd.put("stalker3", t + 9400);
            if (cooldownReady(s, "silent", t) && chance(0.01) && ringSpawn(lvl, p, "silent", 15, 15)) {
                s.cd.put("silent", t + 5000);
                StalkerUtil.playLocal(p, "grace2", 2.0F);
            }
        }
        if (t % 100 == 0) {
            if (ow && StalkerUtil.skyLight(lvl, p.blockPosition()) < 10 && chance(0.02)) spawnStalker4(lvl, p);
            if (ow && p.getY() < 55 && chance(0.05) && !exists(lvl, "tormentor_m", pos, 16)) spawnTormentorM(lvl, p);
        }
        if (t % 300 == 0 && ow && p.getY() < 50 && chance(0.08) && !existsAnywhere(lvl, "c_stalker_bed")) spawnCStalkerBed(lvl, p);
        if (t % 400 == 0 && ow && chance(0.12) && !existsAnywhere(lvl, "tree_stalker")) spawnTreeStalker(lvl, p);
        if (t % 500 == 0) { // cave_stalker_up.js
            if (chance(0.10) && onStone(lvl, p) && chance(0.10)) spawnCaveCStalker(lvl, p);
            if (chance(0.02)) ringSpawn(lvl, p, "something", 20, 20);
        }
        if (t % 900 == 0 && chance(0.03) && !exists(lvl, "c_stalker", pos, 35)) ringSpawn(lvl, p, "c_stalker", 18, 18);
        if (t % 1000 == 0) {
            if (chance(0.03)) spawnIce(lvl, p);
            if (chance(0.08)) ringSpawn(lvl, p, "yelling_creature", 12, 20);
            if (chance(0.02)) spawnRaroNearTree(lvl, p);
        }
        if (t % 2000 == 0 && chance(0.02)) ringSpawn(lvl, p, "something", 20, 20);
        if (t % 6000 == 0 && chance(0.20)) {
            BlockPos d = doorNear(lvl, p, 8, 2);
            if (d != null) spawn(lvl, "stalker_door_2", doorCenter(lvl, d));
        }
        // --- tormentor_door
        if (ow && ++s.tdTimer >= 600) {
            s.tdTimer = 0;
            if (chance(0.10) && !exists(lvl, "tormentor_door", pos, 12)) {
                BlockPos d = doorNear(lvl, p, 8, 2);
                if (d != null) spawn(lvl, "tormentor_door", doorCenter(lvl, d));
            }
        }
        // --- sin cielo: silent_door / stalker_door_3
        if (s.doorSpawn >= 2400) {
            s.doorSpawn = 0;
            if (s.noSky >= 2400 && chance(0.01)) {
                BlockPos d = doorNear(lvl, p, 8, 1);
                if (d != null) {
                    if (R.nextBoolean()) {
                        Vec3 sp = new Vec3(d.getX() + 1.0, d.getY(), d.getZ() + 0.5);
                        if (!exists(lvl, "silent_door", sp, 4)) { spawn(lvl, "silent_door", sp); StalkerUtil.playAt(lvl, sp, "stalker1", 2.0F); }
                    } else {
                        spawn(lvl, "stalker_door_3", Vec3.atBottomCenterOf(d));
                    }
                }
            }
        }
        // --- tormentor_hole (100 s sobre piedra)
        if (t % 20 == 0 && ow && s.stone >= 100) {
            s.stone = 0;
            if (chance(0.50)) spawnTormentorHole(lvl, p);
        }
        // --- cave_stalker (tuneles de piedra)
        if (t % 20 == 0 && ow && onStone(lvl, p) && cooldownReady(s, "cave_stalker", t) && chance(0.20)) {
            double yaw = Math.toRadians(p.getYRot());
            for (int d = 6; d <= 10; d++) {
                double x = p.getX() - Math.sin(yaw) * d, z = p.getZ() + Math.cos(yaw) * d;
                BlockPos b = BlockPos.containing(x, p.getY(), z);
                if (lvl.getBlockState(b).isAir() && !lvl.getBlockState(b.below()).isAir() && !lvl.getBlockState(b.above(2)).isAir()) {
                    spawnFacing(lvl, "cave_stalker", new Vec3(b.getX() + .5, b.getY(), b.getZ() + .5), p);
                    s.cd.put("cave_stalker", t + 6000);
                    break;
                }
            }
        }
    }

    // ------------------------------------------------------------------ reglas concretas
    private static void spawnAtDist(ServerLevel lvl, ServerPlayer p, String id, double dist) { ringSpawn(lvl, p, id, dist, dist); }

    private static void spawnStalker4(ServerLevel lvl, ServerPlayer p) {
        for (int x = -12; x <= 12; x += 2) for (int z = -12; z <= 12; z += 2) for (int y = -2; y <= 2; y++) {
            BlockPos b = p.blockPosition().offset(x, y, z);
            if (StalkerUtil.isGlass(lvl.getBlockState(b)) && !lvl.getBlockState(b.above()).isAir()) {
                Vec3 sp = Vec3.atBottomCenterOf(b);
                if (!exists(lvl, "stalker4", sp, 2)) spawn(lvl, "stalker4", sp);
                return;
            }
        }
    }

    private static void spawnTormentorM(ServerLevel lvl, ServerPlayer p) {
        double a = R.nextDouble() * Math.PI * 2, d = 6 + R.nextDouble() * 6;
        int sx = (int) Math.floor(p.getX() + Math.cos(a) * d), sz = (int) Math.floor(p.getZ() + Math.sin(a) * d);
        int py = p.blockPosition().getY();
        for (int y = py - 4; y <= py + 4; y++) {
            BlockPos at = new BlockPos(sx, y, sz);
            if (lvl.getBlockState(at).isAir() && lvl.getBlockState(at.above()).isAir() && !lvl.getBlockState(at.below()).isAir()) {
                BlockPos[] nb = {at.east(), at.west(), at.north(), at.south(), at.below()};
                for (BlockPos n : nb) if (lvl.getBlockState(n).is(Blocks.STONE)) {
                    spawnFacing(lvl, "tormentor_m", new Vec3(sx + .5, y, sz + .5), p);
                    return;
                }
            }
        }
    }

    private static boolean stoneLike(BlockState s) {
        return s.is(BlockTags.BASE_STONE_OVERWORLD) || s.is(BlockTags.DIRT) || s.is(Blocks.DEEPSLATE);
    }

    private static void spawnCStalkerBed(ServerLevel lvl, ServerPlayer p) {
        double a = R.nextDouble() * Math.PI * 2, d = 8 + R.nextDouble() * 6;
        int tx = (int) Math.floor(p.getX() + Math.cos(a) * d), tz = (int) Math.floor(p.getZ() + Math.sin(a) * d);
        int py = p.blockPosition().getY();
        for (int dy = -3; dy <= 3; dy++) {
            BlockPos b = new BlockPos(tx, py + dy, tz);
            if (stoneLike(lvl.getBlockState(b)) && lvl.getBlockState(b.above()).isAir() && lvl.getBlockState(b.above(2)).isAir()) {
                spawn(lvl, "c_stalker_bed", new Vec3(tx + .5, b.getY() + 1, tz + .5));
                return;
            }
        }
    }

    private static void spawnTreeStalker(ServerLevel lvl, ServerPlayer p) {
        double a = R.nextDouble() * Math.PI * 2, d = 12 + R.nextDouble() * 6;
        int tx = (int) Math.floor(p.getX() + Math.cos(a) * d), tz = (int) Math.floor(p.getZ() + Math.sin(a) * d);
        int py = p.blockPosition().getY();
        for (int dy = -4; dy <= 4; dy++) {
            BlockPos b = new BlockPos(tx, py + dy, tz);
            if (StalkerUtil.isLog(lvl.getBlockState(b))) { spawn(lvl, "tree_stalker", new Vec3(tx + .5, b.getY(), tz + .5)); return; }
        }
    }

    private static void spawnCaveCStalker(ServerLevel lvl, ServerPlayer p) {
        double a = R.nextDouble() * Math.PI * 2, d = 3 + R.nextInt(3);
        int cx = (int) Math.floor(p.getX() + Math.cos(a) * d), cz = (int) Math.floor(p.getZ() + Math.sin(a) * d);
        int py = p.blockPosition().getY();
        for (int y = py + 2; y <= py + 5; y++) {
            BlockPos b = new BlockPos(cx, y, cz);
            if (lvl.getBlockState(b).isAir() && lvl.getBlockState(b.above()).isAir() && !lvl.getBlockState(b.below()).isAir()) {
                Vec3 sp = new Vec3(cx + .5, y, cz + .5);
                if (!exists(lvl, "c_stalker", sp, 6)) spawn(lvl, "c_stalker", sp);
                return;
            }
        }
    }

    private static void spawnIce(ServerLevel lvl, ServerPlayer p) {
        Vec3 r = ring(p, 10, 15);
        int py = p.blockPosition().getY();
        for (int dy = 2; dy >= -3; dy--) {
            BlockPos b = new BlockPos((int) Math.floor(r.x), py + dy, (int) Math.floor(r.z));
            if (StalkerUtil.isIce(lvl.getBlockState(b))) { spawnFacing(lvl, "ice_stalker", new Vec3(r.x, b.getY() + 1, r.z), p); return; }
        }
    }

    public static boolean spawnTormentor(ServerLevel lvl, ServerPlayer p) {
        boolean window = R.nextBoolean();
        BlockPos b = StalkerUtil.findBlock(lvl, p.blockPosition(), 8, 2, 8, 2,
                window ? StalkerUtil::isGlass : s -> StalkerUtil.isDoor(s));
        if (b == null) return false;
        StalkerEntity e = spawn(lvl, "tormentor", new Vec3(b.getX() + .5, b.getY(), b.getZ() + .5));
        if (e instanceof DoorMobs.Tormentor t && window) t.setWindowRun();
        return e != null;
    }

    public static boolean spawnTortured(ServerLevel lvl, ServerPlayer p) {
        BlockPos b = StalkerUtil.findBlock(lvl, p.blockPosition(), 8, 2, 8, 2, StalkerUtil::isGlass);
        if (b == null) return false;
        StalkerEntity e = spawn(lvl, "tortured", new Vec3(b.getX() + .5, b.getY(), b.getZ() + .5));
        if (e instanceof ChaserMobs.Tortured t) t.setGlass(Vec3.atCenterOf(b));
        return e != null;
    }

    private static boolean tunnelOk(ServerLevel lvl, int x, int y, int z) {
        int[][] dims = {{3, 3}, {2, 2}, {3, 2}, {2, 3}, {4, 4}};
        for (int[] d : dims) {
            boolean ok = true;
            for (int dx = 0; dx < d[0] && ok; dx++) for (int dy = 0; dy < d[1] && ok; dy++)
                if (!lvl.getBlockState(new BlockPos(x + dx, y + dy, z)).isAir()) ok = false;
            if (ok && lvl.getBlockState(new BlockPos(x, y - 1, z)).is(Blocks.STONE)) return true;
        }
        return false;
    }

    public static void spawnTormentorHole(ServerLevel lvl, ServerPlayer p) {
        Vec3 loc = null;
        for (int i = 0; i < 30 && loc == null; i++) {
            double a = R.nextDouble() * Math.PI * 2; int d = 5 + R.nextInt(11);
            int cx = (int) Math.floor(p.getX() + Math.cos(a) * d), cz = (int) Math.floor(p.getZ() + Math.sin(a) * d);
            for (int dy = -4; dy <= 4; dy++) {
                int cy = p.blockPosition().getY() + dy;
                if (tunnelOk(lvl, cx, cy, cz)) { loc = new Vec3(cx + .5, cy, cz + .5); break; }
            }
        }
        if (loc == null) loc = new Vec3(p.getX() + 4, p.getY(), p.getZ() + 4);
        spawn(lvl, "tormentor_hole", loc);
        StalkerUtil.playAt(lvl, loc, "pf", 2.0F);
    }

    public static void spawnEvilHunt(ServerPlayer p) {
        ServerLevel lvl = p.serverLevel();
        p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 200, 0, false, false));
        double yaw = Math.toRadians(p.getYRot());
        double fx = -Math.sin(yaw), fz = Math.cos(yaw), rx = Math.cos(yaw), rz = Math.sin(yaw), D = 70;
        int c = R.nextInt(3);
        double x = p.getX(), z = p.getZ();
        if (c == 0) { x += fx * D - rx * D; z += fz * D - rz * D; StalkerUtil.title(p, "§4§l¡VE A LA DERECHA!"); }
        else if (c == 1) { x += fx * D + rx * D; z += fz * D + rz * D; StalkerUtil.title(p, "§4§l¡IZQUIERDA!"); }
        else { x += fx * D; z += fz * D; StalkerUtil.title(p, "§4§l¡ATRÁS!"); }
        spawn(lvl, "evil_hunt", new Vec3(x, p.getY(), z));
    }

    public static void spawnRaroNearTree(ServerLevel lvl, ServerPlayer p) {
        BlockPos log = null;
        for (int i = 0; i < 10 && log == null; i++) {
            int rx = (int) Math.floor(p.getX() + R.nextDouble() * 20 - 10), rz = (int) Math.floor(p.getZ() + R.nextDouble() * 20 - 10);
            for (int y = p.blockPosition().getY() - 3; y <= p.blockPosition().getY() + 3; y++) {
                BlockPos b = new BlockPos(rx, y, rz);
                if (StalkerUtil.isLog(lvl.getBlockState(b))) { log = b; break; }
            }
        }
        if (log == null) return;
        int[][] off = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        int[] o = off[R.nextInt(4)];
        Vec3 g = StalkerUtil.findGround(lvl, log.getX() + o[0] + 0.5, log.getY(), log.getZ() + o[1] + 0.5);
        if (g == null) return;
        spawnFacing(lvl, "raro", g, p);
        BlockPos torch = BlockPos.containing(g.x + o[0], g.y, g.z + o[1]);
        if (lvl.getBlockState(torch).isAir()) lvl.setBlock(torch, Blocks.TORCH.defaultBlockState(), 3);
    }
}
