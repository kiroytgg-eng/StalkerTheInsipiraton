package com.twixxel.stalkers.util;

import com.twixxel.stalkers.ModSounds;
import com.twixxel.stalkers.StalkerConfig;
import com.twixxel.stalkers.TwixxelStalkers;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.Tags;

/** Port de helpers.js + las funciones repetidas en los scripts del addon. */
public final class StalkerUtil {
    private StalkerUtil() {}

    // ---------------------------------------------------------------- jugadores
    public static boolean validTarget(Player p) {
        if (p == null || !p.isAlive() || p.isSpectator()) return false;
        return !p.isCreative() || StalkerConfig.AFFECT_CREATIVE.get();
    }

    public static ServerPlayer nearestPlayer(Entity self, double max) {
        if (!(self.level() instanceof ServerLevel sl)) return null;
        ServerPlayer best = null;
        double bestD = max * max;
        for (ServerPlayer p : sl.players()) {
            if (!validTarget(p)) continue;
            double d = p.distanceToSqr(self);
            if (d < bestD) { bestD = d; best = p; }
        }
        return best;
    }

    public static List<ServerPlayer> playersNear(Level level, Vec3 pos, double r) {
        List<ServerPlayer> out = new ArrayList<>();
        if (level instanceof ServerLevel sl) {
            for (ServerPlayer p : sl.players()) {
                if (validTarget(p) && p.position().distanceToSqr(pos) <= r * r) out.add(p);
            }
        }
        return out;
    }

    // ---------------------------------------------------------------- mirada
    /** estaMirandoAlMonstruo / jugadorMiraAEntidad: producto punto entre la vista y la direccion a la entidad. */
    public static double lookDot(Player p, Entity e) {
        Vec3 to = new Vec3(e.getX(), e.getY() + 1.0D, e.getZ()).subtract(p.getEyePosition());
        double len = to.length();
        if (len < 1.0E-6D) return 1.0D;
        return p.getViewVector(1.0F).dot(to.scale(1.0D / len));
    }

    public static boolean looking(Player p, Entity e, double threshold) { return lookDot(p, e) > threshold; }

    /** hayBloquesEntreEntidadYJugador */
    public static boolean blocked(Level level, Entity from, Player to) {
        Vec3 a = new Vec3(from.getX(), from.getY() + 1.0D, from.getZ());
        Vec3 b = to.getEyePosition();
        return level.clip(new ClipContext(a, b, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, from)).getType() != HitResult.Type.MISS;
    }

    /** mirarAlJugador / facingLocation */
    public static void face(Entity e, Vec3 target) {
        double dx = target.x - e.getX();
        double dz = target.z - e.getZ();
        double dy = target.y - (e.getY() + 1.0D);
        float yaw = (float) (Mth.atan2(dz, dx) * 180.0D / Math.PI) - 90.0F;
        float pitch = (float) -(Mth.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 180.0D / Math.PI);
        e.setYRot(yaw); e.setXRot(pitch);
        e.yRotO = yaw; e.xRotO = pitch;
        if (e instanceof LivingEntity le) {
            le.yBodyRot = yaw; le.yBodyRotO = yaw; le.yHeadRot = yaw; le.yHeadRotO = yaw;
        }
    }

    // ---------------------------------------------------------------- sonidos / UI
    public static void playAt(Level level, Vec3 pos, String name, float volume) {
        SoundEvent ev = ModSounds.get(name);
        if (ev != null) level.playSound(null, pos.x, pos.y, pos.z, ev, SoundSource.HOSTILE, volume, 1.0F);
    }

    /** playsound X @s ~ ~ ~ : solo lo oye ese jugador. */
    public static void playLocal(ServerPlayer p, String name, float volume) {
        SoundEvent ev = ModSounds.get(name);
        if (ev != null && p != null) p.playNotifySound(ev, SoundSource.MASTER, volume, 1.0F);
    }

    public static void stopLocal(ServerPlayer p, String name) {
        if (p != null) p.connection.send(new ClientboundStopSoundPacket(new ResourceLocation(TwixxelStalkers.MODID, name), null));
    }

    public static void stopAll(ServerLevel level) {
        for (ServerPlayer p : level.players()) p.connection.send(new ClientboundStopSoundPacket(null, null));
    }

    public static void stopForAll(ServerLevel level, String name) {
        for (ServerPlayer p : level.players()) stopLocal(p, name);
    }

    public static void actionbar(ServerPlayer p, String text) { p.displayClientMessage(Component.literal(text), true); }

    public static void title(ServerPlayer p, String text) {
        p.connection.send(new ClientboundSetTitlesAnimationPacket(5, 40, 10));
        p.connection.send(new ClientboundSetTitleTextPacket(Component.literal(text)));
    }

    /** title @a title \ue100 : imagen de susto (fuente bitmap con death.png). */
    public static void jumpscareGlyph(ServerPlayer p) {
        p.connection.send(new ClientboundSetTitlesAnimationPacket(0, 40, 10));
        p.connection.send(new ClientboundSetTitleTextPacket(Component.literal("\ue100")
                .withStyle(s -> s.withFont(new ResourceLocation(TwixxelStalkers.MODID, "jumpscare")))));
    }

    // ---------------------------------------------------------------- daño
    public static void kill(ServerPlayer p) {
        if (p != null && p.isAlive()) p.hurt(p.damageSources().genericKill(), Float.MAX_VALUE);
    }

    public static void hurt(ServerPlayer p, float amount) {
        if (p != null && p.isAlive()) p.hurt(p.damageSources().magic(), amount);
    }

    // ---------------------------------------------------------------- bloques
    public static boolean isDoor(BlockState s) { return s.getBlock() instanceof DoorBlock; }
    public static boolean isGlass(BlockState s) { return s.is(Tags.Blocks.GLASS) || s.is(Tags.Blocks.GLASS_PANES); }
    public static boolean isLog(BlockState s) { return s.is(BlockTags.LOGS); }
    public static boolean isIce(BlockState s) { return s.is(BlockTags.ICE); }
    public static boolean isStone(BlockState s) { return s.is(Blocks.STONE); }

    /** Busca el primer bloque que cumpla el predicado (barrido con paso en X/Z, como los scripts). */
    public static BlockPos findBlock(Level level, BlockPos origin, int rx, int ry, int rz, int step, Predicate<BlockState> test) {
        for (int x = -rx; x <= rx; x += step)
            for (int z = -rz; z <= rz; z += step)
                for (int y = -ry; y <= ry; y++) {
                    BlockPos p = origin.offset(x, y, z);
                    if (test.test(level.getBlockState(p))) return p;
                }
        return null;
    }

    public static BlockPos nearestBlock(Level level, Vec3 center, int rx, int ry, int rz, Predicate<BlockState> test) {
        BlockPos o = BlockPos.containing(center), best = null;
        double bd = Double.MAX_VALUE;
        for (int x = -rx; x <= rx; x++)
            for (int y = -ry; y <= ry; y++)
                for (int z = -rz; z <= rz; z++) {
                    BlockPos p = o.offset(x, y, z);
                    if (!test.test(level.getBlockState(p))) continue;
                    double d = Vec3.atCenterOf(p).distanceToSqr(center);
                    if (d < bd) { bd = d; best = p; }
                }
        return best;
    }

    public static void openDoors(Level level, BlockPos c, int rx, int ry, int rz) {
        for (int x = -rx; x <= rx; x++)
            for (int y = -ry; y <= ry; y++)
                for (int z = -rz; z <= rz; z++) {
                    BlockPos p = c.offset(x, y, z);
                    BlockState s = level.getBlockState(p);
                    if (s.getBlock() instanceof DoorBlock d && !s.getValue(DoorBlock.OPEN)) d.setOpen(null, level, s, p, true);
                }
    }

    public static boolean nearDoor(Level level, Vec3 pos, int r) {
        BlockPos o = BlockPos.containing(pos);
        for (int x = -r; x <= r; x++)
            for (int y = -r; y <= r; y++)
                for (int z = -r; z <= r; z++)
                    if (isDoor(level.getBlockState(o.offset(x, y, z)))) return true;
        return false;
    }

    /** breakNearbyGlass: rompe el cristal alrededor. */
    public static void breakGlass(Level level, BlockPos c, int rx, int yMin, int yMax, int rz) {
        for (int x = -rx; x <= rx; x++)
            for (int y = yMin; y <= yMax; y++)
                for (int z = -rz; z <= rz; z++) {
                    BlockPos p = c.offset(x, y, z);
                    if (isGlass(level.getBlockState(p))) level.destroyBlock(p, false);
                }
    }

    public static int skyLight(Level level, BlockPos pos) { return level.getBrightness(LightLayer.SKY, pos); }

    /** Busca el suelo bajo/alrededor de (x,y,z): pies libres + bloque solido debajo. */
    public static Vec3 findGround(Level level, double x, double y, double z) {
        int bx = Mth.floor(x), bz = Mth.floor(z), by = Mth.floor(y);
        for (int dy = 3; dy >= -6; dy--) {
            BlockPos feet = new BlockPos(bx, by + dy, bz);
            BlockPos below = feet.below();
            if (level.getBlockState(below).isFaceSturdy(level, below, Direction.UP)
                    && level.getBlockState(feet).getCollisionShape(level, feet).isEmpty()
                    && level.getBlockState(feet.above()).getCollisionShape(level, feet.above()).isEmpty()) {
                return new Vec3(x, feet.getY(), z);
            }
        }
        return null;
    }

    public static boolean solidAt(Level level, double x, double y, double z) {
        BlockPos p = BlockPos.containing(x, y, z);
        return !level.getBlockState(p).getCollisionShape(level, p).isEmpty();
    }

    public static AABB around(Vec3 c, double r) { return new AABB(c.x - r, c.y - r, c.z - r, c.x + r, c.y + r, c.z + r); }
}
