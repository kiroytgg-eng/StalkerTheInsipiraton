package com.twixxel.stalkers.client;

import com.twixxel.stalkers.ModEntities;
import com.twixxel.stalkers.TwixxelStalkers;
import com.twixxel.stalkers.entity.StalkerEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = TwixxelStalkers.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    private ClientSetup() {}

    @SubscribeEvent
    public static void onRenderers(EntityRenderersEvent.RegisterRenderers e) {
        for (var en : ModEntities.DEFS.entrySet()) {
            register(e, ModEntities.type(en.getKey()), en.getKey(), en.getValue().scale());
        }
    }

    @SuppressWarnings("unchecked")
    private static <T extends StalkerEntity> void register(EntityRenderersEvent.RegisterRenderers e, EntityType<?> type, String id, float scale) {
        e.registerEntityRenderer((EntityType<T>) type, ctx -> new StalkerRenderer<T>(ctx, id, scale));
    }
}
